/* save the cart value */
//api_type('success', 'Sorry something is wrong <a href="shopping-cart">View Cart</a>');

//api_type('danger', 'Sorry something is wrong ');

function saveCart(cat_id,product_id)
{     

    if(cat_id=='' || product_id=='')
    {
      api_type('danger', 'Sorry something is wrong ');
      return false;
    }  
    $.ajax({
      type:'POST',
      dataType:'json', 
      url:'ajax/savecart',
      data:'cat_id='+cat_id+'&product_id='+product_id,
      beforeSend:function(html){  
       loderShow();
     },
     success:function(html){      
      var jsonobject = $.parseJSON(JSON.stringify(html));                      
            if(jsonobject.status=='add')
            {
              api_type('success', 'Product Added into cart <a href="shopping-cart">View Cart</a>');
              $('#cart_item_count').text(jsonobject.total_cart_item);
               // sendR();

             }
             if(jsonobject.status=='fail')
             {
              api_type('danger', 'Sorry some thing is wrong');
            }
            if(jsonobject.status=='old')
            {
              api_type('danger', 'Product already exists into cart');
              //   $("input:checkbox").removeAttr("checked");
            }
            
            loderHide();              

          }
        });

  }
  /******************  for delete cart  ********************/
//alert(SITEURL);
function deletecart(cartId)
{  
  var con= confirm('Are you sure want to delete from cart');
  if(!con)
  {
    return false;
  }
  $.ajax({
    type:'POST',
  //dataType:'json', 
   url:'ajax/deletecart',
   data:'cart_id='+cartId,
  beforeSend:function(html){  
    loderShow();         
  },
  success:function(html){  
    if(html.trim()=='delete')
    {
      api_type('success', 'Product successfully deleted');
      setTimeout(function(){ 
       location.reload();
     }, 3000);

    }
    if(html.trim()=='fail')
    {
      api_type('danger', 'something is wrong');
    } 
    if(html.trim()=='nfound')
    {
      api_type('danger', 'Product not found');
    }        

    loderHide();             

  }
});

}

function cartupdate(cartId,qty)
{  
  $.ajax({
    type:'POST',
  //dataType:'json', 
   url:'ajax/cartupdate',
   data:'cart_id='+cartId+'&qty='+qty,
  beforeSend:function(html){  
    loderShow();         
  },
  success:function(html){    
    if(html.trim()=='update')
    {
      api_type('success', 'Cart Successfully Updated');
      setTimeout(function(){ 
       location.reload();
     }, 3000);

    }
    if(html.trim()=='fail')
    {
      api_type('danger', 'something is wrong');
    } 
    if(html.trim()=='nfound')
    {
      api_type('danger', 'Product not found');
    }        

    loderHide();             

  }
});

}

$('#shipping_pincode').keyup(function(){
var pinlen=$('#shipping_pincode').val();
var pincode=$('#shipping_pincode').val();
if(pinlen.length==6)
{
  checkPincode1(pincode);
}
//alert(pinlen.length);
});

/********** global check pincode ********/
function checkPincode1(pincode)
{  
  $.ajax({
    type:'POST',
    dataType:'json', 
   url:'ajax/checkpincode',
   data:'pincode='+pincode,
  beforeSend:function(html){  
    loderShow();         
  },
  success:function(html){  
  var jsonobject = $.parseJSON(JSON.stringify(html));                      
      //if(jsonobject.status=='fail') 
     // alert(jsonobject.status);
    if(jsonobject.status=='update')
    {    
       $("#pincode").val(pincode);
      // $('#pincode_status').text('Pincode Available but cod not Available');
       $('#pincode_status').text('Delivery is Available');
       $('#pincode_s').addClass('check-green');
       $("#cod11").prop('disabled', true);
    }
    if(jsonobject.status=='updatecod')
    {    
       $("#pincode").val(pincode);
       //$('#pincode_status').text('COD Available.');
       $('#pincode_status').text('Delivery is Available');
       $('#pincode_s').addClass('check-green');
       $("#cod11").prop('disabled', false);
    }
    if(jsonobject.status=='fail')
    {
      $('#pincode_status').text('Pincode not Available');
      $('#pincode_status').addClass('check-red');
      $("#shipping_pincode").val('');
      api_type('danger', 'Delivery not Available in this pincode');
      
    } 
    if(jsonobject.status=='nfound')
    {
      api_type('danger', 'Product not found');
    }        

    loderHide();             

  }
});
}
function checkPincode()
{  
  var pincode=$('#pincode').val();
  if(pincode=='' || pincode.length!=6)
  {
    api_type('danger', 'Please enter valid pincode');
    return false;
  }
  $('#pincode_status').text('');
  $('#pincode_s').removeClass('check-green');
  $('#pincode_status').removeClass('check-red');
  $.ajax({
    type:'POST',
  dataType:'json', 
   url:'ajax/checkpincode',
   data:'pincode='+pincode,
  beforeSend:function(html){  
    loderShow();         
  },
  success:function(html){ 
  var jsonobject = $.parseJSON(JSON.stringify(html));                      
      //if(jsonobject.status=='fail') 
     //alert(jsonobject.status);
    if(jsonobject.status=='update')
    {    
       $("#shipping_pincode").val(pincode);       
       //$('#pincode_status').text('Pincode Available but cod not Available');
       $('#pincode_status').text('Delivery is Available');
       $('#pincode_s').addClass('check-green');
       $("#cod11").prop('disabled', true);
    }
    if(jsonobject.status=='updatecod')
    {    
       $("#shipping_pincode").val(pincode);
       //$('#pincode_status').text('COD Available.');
       $('#pincode_status').text('Delivery is Available');
       $('#pincode_s').addClass('check-green');
       $("#cod11").prop('disabled', false);       
    }
   
    if(jsonobject.status=='fail')
    {
      $('#pincode_status').text('Pincode not Available');
      $('#pincode_status').addClass('check-red');
       $("#shipping_pincode").val('');
      api_type('danger', 'Delivery not Available in this pincode');
      
    } 
    if(jsonobject.status=='nfound')
    {
      api_type('danger', 'Product not found');
    }        

    loderHide();             
          

  }
});
}
/*for the apply coupon codes*/
function applyCoupon()
{
   var coupon_code =$("#coupon_code").val();
   if(coupon_code==''){
     api_type('danger', 'Please Enter Valid Coupon Code');
     return false;     
   }else{
      $.ajax({
      type:'POST',
      url:'ajax/applycoupon',
      data:'coupon_code='+coupon_code,
      beforeSend:function(html){  
        loderShow();         
      },
        success:function(html){   

          if(html.trim()=='successsingle')
          {
            api_type('success', 'Coupon Successfully Applied');
            setTimeout(function(){ 
                 location.reload();
              }, 3000);
             
          }
          if(html.trim()=='failone')
          {
            api_type('danger', 'Sorry Coupon Not found');
          } 
          if(html.trim()=='fail')
          {
            api_type('danger', 'Sorry Coupon Not found');
          }        
          if(html.trim()=='nfound'){
            api_type('danger', 'Coupon Not Found');
          }
           if(html.trim()=='old'){
            api_type('danger', 'Coupon has been already used');
          }
          if(html.trim()=='morethanone'){
            api_type('danger', 'This Coupon can be used only one quantity of product');
          }
          if(html.trim()=='onlyonepack'){
            api_type('danger', 'This Coupon can be used only one quantity of 1 packs of bath wipes');
          }
          if(html.trim()=='morethanfive'){
            api_type('danger', 'This Coupon can be used only five thousand pacage');
          }
          loderHide();             
        }
      });
   }
 }
 /************************ for delete coupons  ***************************/
 function deleteCoupon()
 {
    var con= confirm('Are You sure want to remove counpon');
  if(!con)
  {
      return false;
  }
   var coupon_code =$("#coupon_id").val();
   if(coupon_code==''){
     api_type('danger', 'Sorry coupon not found');
     return false;     
   }else{
      $.ajax({
      type:'POST',
      url:'ajax/deletecoupon',
      data:'coupon_code='+coupon_code,
      beforeSend:function(html){  
        loderShow();         
      },
        success:function(html){                
          if(html.trim()=='successsingle')
          {
            api_type('success', 'Coupon Successfully removed');
            setTimeout(function(){ 
                 location.reload();
              }, 3000);
             
          }
          if(html.trim()=='failone')
          {
            api_type('danger', 'Sorry Coupon Not found');
          } 
          if(html.trim()=='fail')
          {
            api_type('danger', 'Sorry Coupon Not found');
          }        
          if(html.trim()=='nfound'){
            api_type('danger', 'Coupon Not Found');
          }
          loderHide();             
        }
      });
   }

 }
/**************** start here for checkout ***************/
$('#checkout').click(function(){ 

     var trans_no=$('#txnid').val();
     var paymentMethod=$("input[name='paymentmethod']:checked").val();    
     if(typeof(paymentMethod)  === "undefined")
     {
      api_type('danger', 'Please choose the payment method');
        return false;
     }     
    // var shipping_city = validateNotEmpty($("#shipping_city"), 'Please select Shipping city');
    // var shipping_city = validateNotEmpty($("#shipping_locality"), 'Please select Shipping Locality');
    // var shipping_city = validateNotEmpty($("#shipping_pincode"), 'Please select Shipping Pincode');
    // var shipping_city = validateNotEmpty($("#shipping_address"), 'Please select Shipping Address');       
    // var shipping_phone = validateMobile($("#shipping_phone"));

     var phone=isValidPhone($('#shipping_phone').val());  
if($('#city1').val()=='' || $('#shipping_locality').val()=='' || $('#shipping_pincode').val()=='' || $('#shipping_address').val()=='' || $('#shipping_phone').val()=='')
     {     
      api_type('danger', 'Please fill shipping details');
        return false;
     }
     if($('#shipping_address').val()!='')
     {
      if(!phone)
      {
        api_type('danger', 'Please enter valid shipping phone');
        return false;

      }

     }
        if($('#termc').prop("checked") == true)
        {          
         terms=1;
        }
        else
        {     
            api_type('danger', 'Please Select Terms & Conditions');
            return false;
        }
     /** convert sipping city id to name**/
     var val = document.getElementById('city1').value;
      var text = $('#countries').find('option[value="' + val + '"]').attr('id');     
      $('#shipping_city').val(text);
      /** convert billing city id to name**/
     var val2 = document.getElementById('city2').value;
      var text2 = $('#countries2').find('option[value="' + val2 + '"]').attr('id');     
      $('#billing_city').val(text2);
      
      var dataString = $("#orders, #shipping, #orderDetails").serialize(); 
      //return false;
        $.ajax({
        type:'POST',
        dataType:'json', 
        url:'ajax/order',
       // data:filterdata+'&shipping='+formData2,
        data:dataString+'&trans_no='+trans_no,
        beforeSend:function(html){  
          loderShow();
        },
        success:function(html){

            var jsonobject = $.parseJSON(JSON.stringify(html));
            //alert(jsonobject);
            //alert(jsonobject.status);           
            if(jsonobject.status=='add')
            {
                 var retrun =$('#return_tt').val();                
                 var retrun2=retrun+'/'+jsonobject.order_id;
                 $('#return_tt').val(retrun2);
                 $('#orders_id').val(jsonobject.order_id);                  
                 if(paymentMethod=='prepaid')
                 {
                   api_type('success', 'Redirecting you to the payment gateway');
                   $('#payuForm').submit();    
                 }
                 if(paymentMethod=='cod')
                 {
                   $('#cod_order').submit();
                 }
                    
              /* 
                setTimeout(function(){
                        if(pmethod=='paypal') 
                        {
                             $('#'+formId).submit();
                         }
                         if(pmethod=='manual') 
                        {
                             $('#mannual_trans').val(jsonobject.order_id);
                             $('#mannual_paymentff').submit();
                         }
                         if(pmethod=='sofort') 
                        {
                            $('#sofort_trans').val(jsonobject.order_id);
                            $('#sofort_payment').submit();
                         }                      
                    }, 3000);
                */
                         
            }
            if(jsonobject.status=='fail')
            {
                api_type('danger', 'Sorry something is wrong');
            }
            if(jsonobject.status=='old')
            {
                api_type('danger', 'Sorry something is wrong');
                 $("input:checkbox").removeAttr("checked");
            }
            
         loderHide();               
         
        }
     });
});
//***************** contact form  ************************//
$('#contact #contactSubmit').click(function(){
  var name     = validateNotEmpty($("#name"), 'Please enter First Name');
  var email    = validEmail($("#email"));
  var phone    = validateMobile($("#phone"));
  var message  = validateNotEmpty($("#message"), 'Please enter Message');
  if(name && email && phone && message)
  {
    var dataString = $("#contact").serialize();
     $.ajax({
      type:'POST',
      url:'ajax/contact',
      data:dataString,
      beforeSend:function(html){  
        loderShow();         
      },
        success:function(html){                
          if(html.trim()=='successsingle')
          {
            api_type('success', 'Query has been sent');           
             
          }          
          if(html.trim()=='fail')
          {
            api_type('danger', 'Sorry your query is not sent');
          }      
          
          loderHide();             
        }
      });

  }
  else
  {
    api_type('danger', 'Please Fill all the valid fields');
    return false;
  }
});
 /************** login *************/
  function registerForm()
 {
  var name = validateNotEmpty($("#name"), 'Please enter First Name');
  var email    = validEmail($("#reg_email"));
  var phone = validateMobile($("#phone"));
  if ( $("#terms:checked").length )
  {   
   } else {
    api_type('danger', 'Please Check the terms and condition');
    return false;
   }  
  if(email && email && phone)
  {    
    $('#register').submit();      
  }
  else
  {
    api_type('danger', 'Please enter valid data');
    return false;

  }
 }
 function loginForm()
 {
  var email    = validEmail($("#login_email"));
  var password = validateNotEmpty($("#login_password"), 'Please enter password');
  if(email && password)
  {
    $('#login').submit();      
  }
  else
  {
    api_type('danger', 'Please enter valid data');
    return false;

  }
 }
 /*reset password*/
  $('#submitforgetpassword').click(function(){
     var email    = validEmail($("#login_email"));
     if(email)
     {
      return true;
     }
     else
     {
      return false;
     }
  });
    $('#submitresetpassword').click(function(){
     var email    = validEmail($("#login_email"));
     if(email)
     {
      return true;
     }
     else
     {
      return false;
     }
  });
  
/*function to validate not empty*/
      function validateNotEmpty(obj, msg) {
        $(obj).removeClass("error");
        // $(obj).next("div [for='"++"']").remove();
        $(obj).next("div[for='" + obj.attr('id') + "']").remove();
        if (obj.val().length < 1) {
          $(obj).addClass("error");
          //$('#'+obj.attr('id')).focus();
          $(obj).after("<div class='error-message' for='" + obj.attr('id') + "'>" + msg + "</div>");
          return false;
        }
        else {
          return true;
        }
      }
      /*********   valid email  ************************/
      /*function to validate business email*/
      function validEmail(obj) {
        $(obj).removeClass("error");
        $(obj).next("div[for='" + obj.attr('id') + "']").remove();
        if (obj.val().length < 1) {
          $(obj).addClass("error");
          $(obj).after("<div class='error-message' for='" + obj.attr('id') + "'>Please enter email id</div>");
          return false;
        }
        else if (!isValidEmail(obj.val())) {
          $(obj).addClass("error");
          $(obj).after("<div class='error-message' for='" + obj.attr('id') + "'>Email is not valid</div>");
          return false;  

        }
        else {
          return true;
        }
      }
      /*function to check is valid email format*/
      function isValidEmail(email) {
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return regex.test(email);
      }
      /*function to validate mobile number*/
      function validateMobile(obj) {
        $(obj).removeClass("error");
        $(obj).next("div[for='" + obj.attr('id') + "']").remove();
        if (obj.val().length < 1) {
          $(obj).addClass("error");
          $(obj).after("<div class='error-message' for='" + obj.attr('id') + "'>Please enter phone number.</div>");
          return false;
        }
        else if (!isValidPhone(obj.val())) {
          $(obj).addClass("error");
          $(obj).after("<div class='error-message' for='" + obj.attr('id') + "'>Please enter valid phone number.</div>");
          return false;
        }
        else {
          return true;
        }
      }

      function isValidPhone(phone) {
        var regex = /^([0-9]{10})|(\([0-9]{3}\)\s+[0-9]{3}\-[0-9]{4})+$/;
        return regex.test(phone);
      }

      
      $('#newsletter').click(function(){      
       var email = validEmail($("#newsletterEmail"));         
       var email1 = $('#newsletterEmail').val();        
       if(email)
       {
         $.ajax({
          type:'POST',
          url:SITEURL+'ajax/newletter',
          data:'email='+email1,       
          beforeSend:function(html){  
            loderShow();    
          },
          success:function(html){                                   
            if(html.trim()=='success')
            {
              api_type('success', 'You have successfully subscribed');
              $('#newsletterEmail').val(''); 
             // return false;
            }
            if(html.trim()=='old')
            {
              api_type('danger', 'Your Email is already subscribed');
             // $('#newsletterEmail').val(''); 
             // return false;
            }
            if(html.trim()=='fail')
            {
              api_type('danger', 'Sorry something is wrong');
             // return false;
            }

            loderHide();    

          }
        });

       }
       else
       {
        api_type('danger', 'Please enter email Id.');
        return false;
      }
        // alert(email);
      });
$('#newsletterEmail').on('keypress', function(e) {
    var code = e.keyCode || e.which;
    if(code==13){
      $('#newsletter').click();
        // Enter pressed... do anything here...
    }
});
function loderShow()
{
  //alert();
  $('.load-main-div').show();
}
function loderHide()
{
  $('.load-main-div').hide();
}
function api_type(type, message) {
    $.notify(message, {
      type: type
      , close: true
    });

    
  }
  (window.jQuery)

function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

/***********************  start here for google login  ********************************/
      /*google login start here*/
      //  856293864310-5es0412kmug2e6go4p7aalued2m55ae6.apps.googleusercontent.com    radicalreflex
      //  662465907450-ti9lqho00jdgdi1fld617q1ubnrpsar9.apps.googleusercontent.co     my own

        function googleLogin_old()
        {
            var myParams = {  
              //  'clientid' :'485254637352-1qctv68glpkp1pdl03h3j9p6q5oipnmg.apps.googleusercontent.com',
                'clientid' :'906310522080-kp07b82pi4pjg5ack5c63nihcjb77os0.apps.googleusercontent.com',  // by kolan produts
                'cookiepolicy' :'single_host_origin',
                'callback' : 'googleloginCallback',
                'approvalprompt':'force',
               // 'scope' : 'https://www.googleapis.com/auth/plus.profile.emails.read'
               // 'scope' : 'https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/plus.me https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile'
            };
           
            gapi.auth.signIn(myParams);
        }

function googleloginCallback(result)
{
    if(result['status']['signed_in'])
    {
        gapi.client.load('plus','v1', function(){
            var request = gapi.client.plus.people.get({
                'userId': 'me'
            });
            request.execute(function(profile) {
                var email = profile['emails'].filter(function(v) {
                    return v.type === 'account'; // Filter out the primary email
                })[0].value;
                // alert(email);
                // alert(profile.displayName);
                // alert(profile.id);
                $.ajax({
                    url:SITEURL+"ajax/register/",   
                    dataType:'json',
                    type:'POST',
                    data:{'email':email,'name':profile.displayName,'login_from':'google','google_id':profile.id},
                    dataType:'json',      
                    success : function(Jdata) {
                     // alert(Jdata.status);
                        if(Jdata.status=='success'){
                          var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
                           var fields = String(hashes).split(',');
                          var hashes = fields[0];
                          var pro    =    fields[1];
                          if(hashes=='cart=1')
                          {  
                            location.href ="shopping-cart";
                          //alert(hashes);
                          }
                           else if(hashes=='review=1')
                          {  
                            location.href ="write-review?"+pro;
                          //alert(hashes);
                          }
                          else{
                            location.href ="my-profile";
                          }

                           // location.href = siteUrl+"users/dashboard";
                        }
                        if(Jdata.status=='fail')
                        {
                          api_type('danger', 'Sorry Invalid Input');
                          return false;
                        }
                         if(Jdata.status=='noemail')
                        {
                          api_type('danger', 'Sorry Email Id is not found');
                          return false;
                        }
                    },
                    beforeSend: function() {
                      loderShow();                                                        
                    },
                    complete: function() {
                        loderHide();  
                    }
                }); 
            });
        });
    }
    else
    {
        /*app not authorize*/
    }
 
}

/************** end google login ****************/

/******************* start here for facebook login**************/
  
function fbLogin()
{   
    FB.login(function(response) {
        if (response.status === 'connected') {
                getFbUserDetail();
        }
        else if (response.status === 'not_authorized') {

        }
        else
        {

            // The person is not logged into Facebook, so we're not sure if
            // they are logged into this app or not.
        }
    }, {scope: 'public_profile,email',return_scopes: true});
}
function statusChangeCallback(response) {
    
    if (response.status === 'connected') {
       // getFbUserDetail();
    } else if (response.status === 'not_authorized') {
    
      //document.getElementById('status').innerHTML = 'Please log ' + 'into this app.';
    } else {
      
      //document.getElementById('status').innerHTML = 'Please log ' + 'into Facebook.';
    }
}



function getFbUserDetail()
{
   
    FB.api('/me?fields=email,name', function(response) {
        $.ajax({
            url:SITEURL+"ajax/register/",    
            dataType:'json',
            type:'POST',
      // use this page for write the login and set session and chealready register or not
            data:{'email':response.email,'name':response.name,'login_from':'facebook','facebook_id':response.id},
            dataType:'json',      
            success : function(Jdata) {
              if(Jdata.status=='success'){
                    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
                    var fields = String(hashes).split(',');
                    var hashes = fields[0];
                    var pro    =    fields[1];

                    if(hashes=='cart=1')
                    {  
                      location.href ="shopping-cart";
                    //alert(hashes);
                    }
                      else if(hashes=='review=1')
                          {  
                            location.href ="write-review?"+pro;
                          //alert(hashes);
                          }
                    else{
                      location.href ="my-profile";
                    }

                     // location.href = siteUrl+"users/dashboard";
                  }
                 if(Jdata.status=='fail')
                  {
                    api_type('danger', 'Sorry Invalid Input');
                    return false;
                  }
                   if(Jdata.status=='noemail')
                  {
                    api_type('danger', 'Sorry Email Id is not found');
                    return false;
                  }
            },
            beforeSend: function() {
                loderShow();
            },
            complete: function() {
               loderHide();
            }
        });  
    });
}
/*facebook login end here*/

/************* start here for shipping  **********/
function getShipping(city_id)
{
if(city_id)
       {
         $.ajax({
          type:'POST',
          url:SITEURL+'ajax/shipping',
          data:'city='+city_id,       
          beforeSend:function(html){  
            loderShow();    
          },
          success:function(html){                                           
            if(html.trim()=='success')
            {
              location.reload();
            }          
            if(html.trim()=='fail')
            {
              //api_type('danger', 'Entschuldige, etwas stimmt nicht.');
            }
             if(html.trim()=='nfound')
            {
              api_type('danger', 'Sorry shipping amount not found');
            }

            loderHide();    

          }
        });

       }
       else
       {
        api_type('danger', 'Please select valid city');
        return false;
      }
}
   

    function showMyImage(fileInput,id) {
       var files = fileInput.files;
     
       for (var i = 0; i < files.length; i++) {           
           var file = files[i];
           var imageType = /image.*/;     
           if (!file.type.match(imageType)) {
               continue;
           }  
           document.getElementById("thumbnil"+id).style.display='block';         
           var img=document.getElementById("thumbnil"+id);            
           img.file = file;    
           var reader = new FileReader();
           reader.onload = (function(aImg) { 
               return function(e) { 
                   aImg.src = e.target.result; 
               }; 
           })(img);
           reader.readAsDataURL(file);
       }    
   }


/******************  start here for rating  ****************/
$(document).ready(function(){
  
  /* 1. Visualizing things on Hover - See next part for action on click */
  $('#stars li').on('mouseover', function(){
    var onStar = parseInt($(this).data('value'), 10); // The star currently mouse on
   
    // Now highlight all the stars that's not after the current hovered star
    $(this).parent().children('li.star').each(function(e){
      if (e < onStar) {
        $(this).addClass('hover');
      }
      else {
        $(this).removeClass('hover');
      }
    });
    
  }).on('mouseout', function(){
    $(this).parent().children('li.star').each(function(e){
      $(this).removeClass('hover');
    });
  });
  
  
  /* 2. Action to perform on click */
  $('#stars li').on('click', function(){
    var onStar = parseInt($(this).data('value'), 10); // The star currently selected
    var stars = $(this).parent().children('li.star');
    
    for (i = 0; i < stars.length; i++) {
      $(stars[i]).removeClass('selected');
    }
    
    for (i = 0; i < onStar; i++) {
      $(stars[i]).addClass('selected');
    }
    
    // JUST RESPONSE (Not needed)
    var ratingValue = parseInt($('#stars li.selected').last().data('value'), 10);
    var msg = "";
    if (ratingValue > 1) {
        msg = "Thanks! You rated this " + ratingValue + " stars.";
    }
    else {
        msg = "We will improve ourselves. You rated this " + ratingValue + " stars.";
    }
    var current_rating=$('#rating_value').val(ratingValue);   
  }); 
  
});

 $("#rating").submit(function(e){
     var current_rating=$('#rating_value').val(); 
   if(current_rating=='')
   {  
    api_type('danger', 'Please select Ratings');
    e.preventDefault();    
   } 
                
   });
/***************** start here for share on social media **************/
function share()
{
    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left;
    var dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top;
    var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;
    var w=400;
    var h=200;
    var left = ((width / 2) - (w / 2)) + dualScreenLeft;
    var top = ((height / 2) - (h / 2)) + dualScreenTop;
    /*********** using ajax ***********/
     // $.ajax({
     //      type:'POST',
     //      url:SITEURL+'ajax/share',
     //      data:'city='+city_id,       
     //      beforeSend:function(html){  
     //        loderShow();    
     //      },
     //      success:function(html){                                           
     //        if(html.trim()=='success')
     //        {
              
     //        }          
     //        if(html.trim()=='fail')
     //        {
              
     //        }
            
     //        loderHide();    

     //      }
     //    });
    /************ end ajax     ********/
    var newWindow = window.open(SITEURL+'share', 'popup', 'resizable=no,scrollbars=0,toolbar=0,menubar=0,location=0,directories=0,channelmode=0,addressbar=0, status=0, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
     newWindow.my_special_setting = "Hello World";
    // Puts focus on the newWindow
    if (window.focus) {
        newWindow.focus();
    }
  //window.open('http://localhost/colon/share','popup','width=300,height=200');
}


//add event listener to the first share button


$(document).ready(function(){
        $('#share_btn1').click(function(e){
            e.preventDefault(); 
            FB.ui(
            {
                method: 'feed',
              //  name: "{{ user_name }}'s FOF",
                link: "http://kolan.co.in/",
                picture: "http://kolan.co.in/images/header-bg.jpg",
                caption: window.location.href,
                description: 'This FOF was taken by {{ user_name }}',
                message: ''
            });     
        });
        $('#share_button2').click(function(e){
            e.preventDefault(); 
            FB.ui(
            {
                method: 'feed',
              //  name: "{{ user_name }}'s FOF",
                link: "https://mysite.com/uploader/{{current_fof}}/share_fof/",
                picture: "http://kolan.co.in/images/header-bg.jpg",
                caption: window.location.href,
                description: 'This FOF was taken by {{ user_name }}',
                message: ''
            });     
        });          
        $('#share_button3').click(function(e){
            e.preventDefault(); 
            FB.ui(
            {
                method: 'feed',
                //name: "{{ user_name }}'s FOF",
                link: "https://mysite.com/uploader/{{current_fof}}/share_fof/",
                picture: imgsArray[0].src,
                caption: window.location.href,
                description: 'This FOF was taken by {{ user_name }}',
                message: ''
            });     
        });
});

/**********  start here for google map ************/
      
        $('.google-map')

            .click(function() {

                $(this).find('iframe').addClass('clicked')

            })

            .mouseleave(function() {

                $(this).find('iframe').removeClass('clicked')

            });

   function gotohome()
    {     
        window.location = SITEURL+"#store-locator";
    }

$('#sameAddress').click(function(){
   if($('#sameAddress').prop("checked") == true)
        {         
          $('#city2').val($('#city1').val());
           $('#billing_city').val($('#shipping_city').val());
           $('#billing_locality').val($('#shiping_locality').val());
           $('#billing_pincode').val($('#shiping_pincode').val());
           $('#billing_address').val($('#shiping_address').val()); 
           $('#billing_phone').val($('#shipping_phone').val());   
        }
        else
        {
          $('#city2').val('');
           $('#billing_city').val('');
           $('#billing_locality').val('');
           $('#billing_pincode').val('');
           $('#billing_address').val('');
           $('#billing_phone').val(''); 
        }
});

$('#sameAddress2').click(function(){
   if($('#sameAddress2').prop("checked") == true)
        {         
           $('#city2').val($('#city1').val());
           $('#billing_locality').val($('#shipping_locality').val());
           $('#billing_pincode').val($('#shipping_pincode').val());
           $('#billing_address').val($('#shipping_address').val());    
           $('#billing_phone').val($('#shipping_phone').val());    
        }
        else
        {
           $('#city2').val('');
           $('#billing_locality').val('');
           $('#billing_pincode').val('');
           $('#billing_address').val(''); 
           $('#billing_phone').val('');
        }
});

$(document).on('click','#scroll-to-top',function(){
$('html,body').animate({scrollTop:0},500);
return false;
});

// button control
$(document).scroll(function(e){
var scrollPos = $(this).scrollTop();
if(scrollPos < 100){
$('#scroll-to-top').addClass('hide-scroll');
}
else{
$('#scroll-to-top').removeClass('hide-scroll');
}
});

/*********************/ 

       $(document).ready(function() {
           $("#close").click(function() {
               $("#popup-home, #balck-home").fadeOut();
               $("body").removeClass('over');
           });
           //$("body").addClass('over');
       });
       /*   $(window).load(function() {
              $("body").addClass('over');
            
          });*/
$('#pop-btn').click(function(){
  $('#close').click();
});
/************** new details you tube video  **********/
function showNewsVideoPopup(video)
{
  $('#animation-video').modal('show');
  $('#animation-video .modal-body').html('<iframe width="100%" height="300px" src="https://www.youtube.com/embed/'+video+'" frameborder="0" allowfullscreen></iframe>');
}

  $('#animation-video').on('hidden.bs.modal', function () {
  $('#animation-video .modal-body').empty();
  });

  /*************** for remove section on mobile for login register ******************/
 
      if($(window).width() <= 767){
        var width1 = $(window).width();
       // alert(width1);
        $('#forDesktop').remove();  
        $('#forMobile').show(); 
        $('#coupon_desk').remove();  
        $('#coupon_mobile').show(); 
      }

      if($(window).width() > 767){
        var width1 = $(window).width();
       // alert(width1);
        $('#forMobile').remove();  
      //  $('#forMobile').show(); 
        // for coupon code
        $('#coupon_mobile').remove();  
        $('#coupon_desk').show(); 
      }
 
 /****************** open gallery mannual on press release *********************/ 
 $('.opengall .gallImage').click(function(event){
// $(document).on("click", '.opengall .gallImage', function(event) {   
  var fimage=$(this).attr('data-id');  
  var cap1=$(this).attr('alt'); 
  var array=[];
  $('.opengall .gallImage').each(function() {    
     var images=$(this).attr('data-id');
      var cap=$(this).attr('alt');
          
     if(images!='')
     {
      if(images!=fimage)
      {
        array.push({ src: images, thumb: images,subHtml: cap});
      }
      
     }
   
     });
 
  array.unshift({ src: fimage, thumb: fimage,subHtml: cap1});
 
  if(fimage!='')
  {
    $(this).lightGallery({
         dynamic: true,
         thumbnail:true,         
         dynamicEl:array       
         })

  }
     
   
 
});

//
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
});


    function isNumber(evt) {
      var iKeyCode = (evt.which) ? evt.which : evt.keyCode
      if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
        return false;
      return true;
    }   
/********************** for polls **********************/

  $('#polls #submitpoll').click(function(){    
   var dataString = $("#polls").serialize();    
       if(dataString)
       {
         $.ajax({
         type:'POST',
         dataType:'json', 
         url:'ajax/polls', 
        data:dataString,       
          beforeSend:function(html){  
            loderShow();    
          },
          success:function(html){  
          var jsonobject = $.parseJSON(JSON.stringify(html));   
         // alert(jsonobject);                           
            if(jsonobject.status=='success')
            {      
               loderHide(); 
               closeNav();        
               $("#yesforsure").text(jsonobject.yesforsure);
               $("#maybe").text(jsonobject.maybe_per);
               $("#ofcourse").text(jsonobject.ofcourse_per);
              //$('#yesforsuefffffd').html('sdffsdfsdfd');
              api_type('success', 'You have successfully submited');
            }                                 
            
            if(jsonobject.status=='old')
            {
              closeNav(); 
              api_type('danger', 'Your answer has already been submitted');             
            }
            if(jsonobject.status=='fail')
            {
              api_type('danger', 'Sorry something is wrong');             
            }

            loderHide();    

          }
        });

       }
       else
       {
        api_type('danger', 'Please enter email Id.');
        return false;
      }
        // alert(email);
      });

  /*********  for product gallery ********/
    $(document).on("click", '.openGallery', function(event) { 

    var images=$(this).attr('data-id');
    //alert(images);
   // var fimage=$(this).attr('data-id'); 
    var  res = images.split(",");
    var array=[];
    var array2=[];
    if(res!='')
    {
     for (i = 0; i < res.length; i++) 
        { 
          var tt='image/'+res[i];
        array2.push({ src: tt, thumb: tt });        
        }  
    }    
    if(array2!='')
    {
        $(this).lightGallery({
         dynamic: true,
         thumbnail:true,
         dynamicEl:array2          
         })
    }

  
    // var image=$(this).attr('src');   
    // var images=$(this).attr('data-id');
    // var fimage=$(this).attr('data-id'); 
    // var  res = images.split(",");
    // var array=[];
    // $('.openGallery').each(function() {    
    //  var images=$(this).attr('data-id');    
    //  if(images!='')
    //  {
    //     if(images!=fimage)
    //     {
    //         array.push({ src: images, thumb: images});
    //     }
        
    //  }     
    //  });   
    // array.unshift({ src: fimage, thumb: fimage});    
    // if(fimage!='')
    // {
    //     $(this).lightGallery({
    //      dynamic: true,
    //      thumbnail:false,
    //      dynamicEl:array       
    //      })
    // }
   
});
  function  changeshippingcity()
    {
      var val = document.getElementById('city1').value;
      var text = $('#countries').find('option[value="' + val + '"]').attr('id');
      $('#shipping_city').val(text);

    }


 /*   $(document).mouseup(function(e) { 
        var targetbox = $('.navbar-collapse'); 
        if (!targetbox.is(e.target) && targetbox.has(e.target).length == 0) { 
            $('.navbar-collapse').hide('fast'); 
    } 
});*/ 

/**************** for order cancelled by u ****************/
function updateAction(order_id)
{ 
  var action=$('#actionUserOrder'+order_id).val();  
    if(action=='')
     {     
        api_type('danger', 'Please select action');
        return false;
     }
     else
     {
        $.ajax({
        type:'POST',
      //dataType:'json', 
       url:'ajax/ordercanceluser',
       data:'order_id='+order_id+'&action='+action,
      beforeSend:function(html){  
        loderShow();         
      },
      success:function(html){    
        if(html.trim()=='update')
        {
          api_type('success', 'Order Successfully Updated');
          setTimeout(function(){ 
           location.reload();
         }, 3000);

        }
        if(html.trim()=='fail')
        {
          api_type('danger', 'something is wrong');
        } 
        if(html.trim()=='nfound')
        {
          api_type('danger', 'Order not found');
        }        

        loderHide();             

      }
    });

     }

}

/************ for the shipping address ***********/
$('#submitProfileShipping').click( function() {  
  var val = document.getElementById('city1').value;
      var text = $('#countries').find('option[value="' + val + '"]').attr('id'); 
      $('#shipping_city').val(text);
      /** convert billing city id to name**/
     var val2 = document.getElementById('city2').value;
      var text2 = $('#countries2').find('option[value="' + val2 + '"]').attr('id');     
      $('#billing_city').val(text2);
      return true;
  
});