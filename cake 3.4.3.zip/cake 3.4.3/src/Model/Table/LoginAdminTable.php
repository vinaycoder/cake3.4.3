<?php
namespace App\Model\Table;
use Cake\ORM\Table;
use Cake\Validation\Validator;

class LoginAdminTable extends Table
{
    public function initialize(array $config)
    { 
  
       
    }
    
    public function findAuth(\Cake\ORM\Query $query, array $options)
    {
        $query
            ->select([])
            ->where(['LoginAdmin.status_id' => STATUS_ACTIVE]);
            print_r($query);
            die;
        return $query;
    }
    
  
}