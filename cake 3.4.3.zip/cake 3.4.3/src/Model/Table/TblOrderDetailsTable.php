<?php
namespace App\Model\Table;
use Cake\ORM\Table;
use Cake\Event\Event;
use ArrayObject;
use Cake\Validation\Validator;
class TblOrderDetailsTable extends Table
{  
    
  public function validationDefault(Validator $validator)
    {
      
    }

    public function validationUpdate(Validator $validator)
    {
      
    }

     public function validationPref(Validator $validator)
    {
                      
           
        }


   public function initialize(array $config)
    { 
     $this->belongsTo('tbl_order_master', [
        'foreignKey' => 'order_id',
  ]);
     
       
  //   $this->belongsTo('erp_mem_plan_master', [
  //       'foreignKey' => 'mem_pan_id',       

  // ]);
   
  //   $this->hasMany('LoginCustomer', [
  //       'foreignKey' => 'erp_customer_id',
  // ]);

       
    }
    
}