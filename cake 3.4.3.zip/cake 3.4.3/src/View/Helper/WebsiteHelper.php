<?php
namespace App\View\Helper;
use Cake\View\Helper;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
class WebsiteHelper extends Helper
{
  public function getCasestudyImages($id,$type)
  {
    $datafasd=array();
    $datay = TableRegistry::get('tbl_casestudy_images');
    $query = $datay->find()            
    ->where(['casestudy_id'=>$id,'type'=>$type])
    ->order(['id'=>'ASC']);
    foreach ($query as $key => $value) {
      $datafasd[]=$value;
    }
    return $datafasd;
  }
  public function getSlideShow()
  {
    $datay = TableRegistry::get('tbl_slide');
    $query = $datay->find()            
    ->where(['active'=>1])
    ->order(['id'=>'desc']);
    return $query;
  }
  public function getCity()
  {
    $datafasd=array();
    $data = TableRegistry::get('city_master');
    $queryqt = $data->find()                 
    ->order(['name'=>'asc']); 
    foreach ($queryqt as $key => $value) {
      $datafasd[$value->id]=$value->name;
    }
    return $datafasd;
  }
  public function getCategoryDetails()
  {
    $datay = TableRegistry::get('category');
    $query = $datay->find()            
    ->where(['active'=>1])
    ->order(['id'=>'asc']);
    return $query;
  }
  public function getCategorySlug()
  {
    $datay = TableRegistry::get('category');
    $query = $datay->find()
    ->select(['slug'])            
    ->where(['active'=>1])
    ->order(['id'=>'asc']);
    foreach ($query as $key => $value) {
      $slug[]=$value['slug'];
    }
    return $slug;
  }
public function getRecentPosts()
  {
    $connection = ConnectionManager::get('test');
    $query = $connection->execute("SELECT * FROM wp_posts where post_type='post' and post_status='publish' order by id desc limit 0, 8")->fetchAll('assoc'); 
    //pr($results); 

    $slug='';
   //  $datay = TableRegistry::get('wp_posts');
   //  $query = $datay->find()            
   //  ->where(['post_status'=>'publish','post_type'=>'post'])
   //  ->order(['id'=>'desc'])
   // ->limit(8);
    foreach ($query as $key => $value) {
      $slug[]=$value;
    }
    return $slug;       
 

  }
  public function getCategoryDetailsById($id=null)
  {
    $datay = TableRegistry::get('category');
    $query = $datay->find()            
    ->where(['active'=>1,'id'=>$id]);    
    return $query;
  }
  public function getCategoryDetailsBySlug($id=null)
  {

    $datay = TableRegistry::get('category');
    $query = $datay->find()            
    ->where(['active'=>1,'slug'=>$id]); 
    return $query;
  }
  public function getAllNews()
  {
    $datay = TableRegistry::get('tbl_news');
    $query = $datay->find()            
    ->where(['active'=>1]); 
    return $query;
  }
  public function getAllNewsHome()
  {
    $datay = TableRegistry::get('tbl_news');
    $query = $datay->find()            
    ->where(['active'=>1])
    ->limit(3);
    return $query;
  }
  public function getAllPressNews()
  {
    $datay = TableRegistry::get('tbl_press');
    $query = $datay->find()            
    ->where(['active'=>1]); 
    return $query;
  }
  public function getAllMediaKit()
  {
    $datay = TableRegistry::get('tbl_mediakit');
    $query = $datay->find()            
    ->where(['active'=>1]); 
    return $query;
  }
  public function getNewsBySlug($slug)
  {
    $datay = TableRegistry::get('tbl_news');
    $query = $datay->find()            
    ->where(['slug'=>$slug]); 
    return $query;
  }
  public function getNextPreviousSlug($slug)
  {
    $pre=null;
    $next=null;
    $datay = TableRegistry::get('tbl_news');
    $query = $datay->find()
    ->select(['id','slug'])            
    ->where(['slug'=>$slug]);
    foreach ($query as $key => $value) {
      $value=$value;      
     }
     /***** for previous ****/ 
    $query1 = $datay->find()
    ->select(['slug','id'])            
    ->where(['id <'=>$value['id']])
    ->order(['id'=>'desc'])
    ->limit(1);
    foreach ($query1 as $key1 => $value1) {
      $pre=$value1;      
     }
    /***** for next ****/ 
    $query2 = $datay->find()
    ->select(['slug','id'])            
    ->where(['id >'=>$value['id']])
    ->order(['id'=>'asc'])
    ->limit(1);
    foreach ($query2 as $key2 => $value2) {
      $next=$value2;      
     }
    return array('pre'=>$pre['slug'],'next'=>$next['slug']);
  }

  public function getNewsImage($id)
  {
    $datay = TableRegistry::get('tblgalleryphotos');
    $query = $datay->find()            
    ->where(['proj_id'=>$id]); 
    return $query;
  }
  public function getCategoryFeature($cat_id=null)
  {
    $datay = TableRegistry::get('tbl_category_feature');
    $query = $datay->find()            
    ->where(['cat_id'=>$cat_id])
    ->limit(8)
    ->order(['orders'=>'asc']);    
    return $query;
  }
  public function getCategoryUtility($cat_id=null)
  {
    $datay = TableRegistry::get('tbl_category_utility');
    $query = $datay->find()            
    ->where(['cat_id'=>$cat_id])
    ->order(['orders'=>'asc']);     
    return $query;
  }
  public function getCategoryKnowMore($cat_id=null)
  {
    $datay = TableRegistry::get('tbl_other_uses');
    $query = $datay->find()            
    ->where(['cat_id'=>$cat_id]);     
    return $query;
  }
  public function getCategoryKnowMoreDetails($know_more=null)
  {
    $datay = TableRegistry::get('tbl_other_uses_details');
    $query = $datay->find()            
    ->where(['other_uses_id'=>$know_more]);     
    return $query;
  }
  public function getCategoryFaq($cat_id=null)
  {
    $datay = TableRegistry::get('tbl_faq');
    $query = $datay->find()            
    ->where(['cat_id'=>$cat_id])
    ->order(['orders'=>'asc']);       
    return $query;
  }
  public function getCategoryFaqFront($cat_id=null)
  {
    $datay = TableRegistry::get('tbl_faq');
    $query = $datay->find()            
    ->where(['cat_id'=>$cat_id])
    ->limit(5)
    ->order(['orders'=>'asc']);    
    return $query;
  }
  /*******  start here for products  ***********/
  public function getProducts($cat_id=null)
  {
    $datay = TableRegistry::get('products');
    $query = $datay->find()            
    ->where(['category'=>$cat_id,'active'=>1]);     
    return $query;
  }
  public function getProductsImages($pro_id=null)
  {
    $datay = TableRegistry::get('products_images');
    $query = $datay->find()            
    ->where(['product_id'=>$pro_id]);
    ///->limit(1); 
    foreach ($query as $key => $value) {
      $array[]=$value['images'];
    }    
    return $array;
  }
  public function productNames($pieces=null)
  {
   if($pieces==1)
   {
    $icons='1-piece.png';
  }
  elseif($pieces==3)
  {
    $icons='3-pieces.png';
  }
  elseif($pieces>3)
  {
    $icons='5-pieces.png';
  }
  else
  {
    $icons='1-piece.png';
  }
  if($pieces==1)
  {
    $piece='';    
  }
  else
  {
    $piece='s';
  }
  return array('icon'=>$icons,'piece'=>$piece);
}
/* start here to maintain cart */

  public function createCookie()
    { 
      if(!isset($_COOKIE['cart_value_cookies'])) 
      {
         setcookie('cart_value_cookies', time(),time() + (10 * 365 * 24 * 60 * 60),'/');        
      }
    }

public function getCookie()
  {
    if(isset($_COOKIE['cart_value_cookies'])) 
    {
       return $_COOKIE['cart_value_cookies'];
    }
  }

  /*******************************   get cart count value       *******************************************/
public function cartValue($cookie=null,$user_id=null)
{

  if(isset($_SESSION['u_user_id']))
  {     
        $data = TableRegistry::get('tbl_cart');
        $queryqt = $data->find()
                  ->where(['user_id'=>$user_id,'del'=>'0'])
                  ->group(['product_id'])
                  ->count(); 
      $objCount=  $queryqt;          
  }
  else
  {
    if(!empty($cookie)) 
      {      
        $data = TableRegistry::get('tbl_cart');
        $queryqt = $data->find()
                  ->where(['current_cookie'=>$cookie,'user_id IS'=>null,'del'=>'0'])
                  ->group(['product_id'])
                  ->count();
        $objCount=  $queryqt; 
                
      }
  }
  return $objCount;
}

/***************  for viewing the cart  ******************/
/*  for other type logo/ci */
public function ViewCart($cookie=null,$user_id=null)
{
  $query1='';
  if(!empty($user_id))
  {
           $data = TableRegistry::get('tbl_cart');       
           $query1 = $data->find('all')  
                   ->group(['product_id'])
           ->select(['tbl_cart.id','tbl_cart.coupon_id','tbl_cart.coupon_code','tbl_cart.product_id','tbl_cart.quantity','tbl_cart.category_id','tbl_cart.shipping_id','tbl_cart.shipping_amt','category.name','category.id','tbl_cart.current_cookie','tbl_cart.user_id','tbl_cart.add_time','products.name','products.code','products.id','products.price','products.price2','products.stock','products.pieces','products.description','products.weight']) 
          // ->where(['tbl_cart.current_cookie'=>$cookie])            
        //->order(['Categories.name' => 'ASC'])
        ->join([           
            'products' => [
                'table' => 'products',
                'type' => 'inner',
                'conditions' => 'products.id = tbl_cart.product_id and tbl_cart.user_id="'.$user_id.'" and tbl_cart.del="0"'
            ],
              'category' => [
                'table' => 'category',
                'type' => 'inner',
                'conditions' => 'category.id = products.category'
            ]
        ]);
 
  }
  else
  {
    if(!empty($cookie))
    {
           $data = TableRegistry::get('tbl_cart');       
           $query1 = $data->find('all')  
           ->group(['product_id'])
           ->select(['tbl_cart.id','tbl_cart.coupon_id','tbl_cart.coupon_code','tbl_cart.product_id','tbl_cart.quantity','tbl_cart.category_id','tbl_cart.shipping_id','tbl_cart.shipping_amt','category.name','category.id','tbl_cart.current_cookie','tbl_cart.user_id','tbl_cart.add_time','products.name','products.code','products.price','products.price2','products.stock','products.pieces','products.id','products.description','products.weight']) 
          // ->where(['tbl_cart.current_cookie'=>$cookie])            
        //->order(['Categories.name' => 'ASC'])
        ->join([           
            'products' => [
                'table' => 'products',
                'type' => 'inner',
                'conditions' => 'products.id = tbl_cart.product_id and tbl_cart.current_cookie="'.$cookie.'" and tbl_cart.del="0" and tbl_cart.user_id IS NULL'
            ],
              'category' => [
                'table' => 'category',
                'type' => 'inner',
                'conditions' => 'category.id = products.category'
            ]
        ]);
       
      //prd('vinay');
     
    }      }      if($query1->count()>0)   {     return $query1;   }   else
{     return null;   }
  
}

public function cartSize($id)
{
  $size=cart_quantity();  
  foreach($size as $size) 
  {
    $p='';
    if($id!='')
    {
      if($id==$size)
      {
        $p='selected';
      }
      
    }
    $options .= '<option value="'.$size.'" '.$p.'>'.$size.'</option>';
  }
  return $options;

}

  public function getTax()
  {
    $datay = TableRegistry::get('tax');
    $query = $datay->find()            
    ->where(['active'=>1])
    ->limit(1);
    foreach ($query as $key => $value) {
      $val[]=$value;
    }
    return $val;
  }

  public function findAll($table,$cond)
{
  $data = TableRegistry::get($table);
        $queryqt = $data->find()
                  ->where($cond)
                  ->order(['id'=>'desc']);
  if(!empty($queryqt))
  {
      foreach ($queryqt as $key => $value) {
      $obj[]=$value;
      } 
      return $obj;
  }
  else
  {
    return null;
  }

}

public function getReview($pro_id=null)
{
  $query1='';
  if(!empty($pro_id))
  {
           $data = TableRegistry::get('tbl_ratings');       
           $query1 = $data->find('all') 
           ->order(['tbl_ratings.id' => 'DESC']) 
           ->select(['tbl_ratings.rating_value','tbl_ratings.title','tbl_ratings.description','tbl_ratings.created_date','tblusers.name','tblusers.email','tblusers.google_id','tblusers.facebook_id','tblusers.profile_image']) 
          // ->where(['tbl_cart.current_cookie'=>$cookie])            
        //->order(['Categories.name' => 'ASC'])
           ->limit(8)
        ->join([           
            'tblusers' => [
                'table' => 'tblusers',
                'type' => 'inner',
                'conditions' => 'tblusers.id = tbl_ratings.user_id and tbl_ratings.product_id="'.$pro_id.'" and tbl_ratings.active="1" and tbl_ratings.admin_approve="1"'
            ]
        ]);
 
   if($query1->count()>0)
   {     
    return $query1; 
  }  
    else
    {    
     return null; 
    }

  }
  else
  {
    return null;
  }      
  }

public function getReview2($pro_id=null)
{
  $query1='';
  if(!empty($pro_id))
  {
           $data = TableRegistry::get('tbl_ratings');       
           $query1 = $data->find('all') 
           ->order(['tbl_ratings.id' => 'DESC']) 
           ->select(['tbl_ratings.rating_value','tbl_ratings.title','tbl_ratings.description','tbl_ratings.created_date','tblusers.name','tblusers.email','tblusers.google_id','tblusers.facebook_id','tblusers.profile_image']) 
          // ->where(['tbl_cart.current_cookie'=>$cookie])            
        //->order(['Categories.name' => 'ASC'])
        //   ->limit(['8'])
        ->join([           
            'tblusers' => [
                'table' => 'tblusers',
                'type' => 'inner',
                'conditions' => 'tblusers.id = tbl_ratings.user_id and tbl_ratings.product_id="'.$pro_id.'" and tbl_ratings.active="1" and tbl_ratings.admin_approve="1"'
            ]
        ]);
 
   if($query1->count()>0)
   {     
    return $query1; 
  }  
    else
    {    
     return null; 
    }

  }
  else
  {
    return null;
  }      
  }

public function getStoreCity()
{
  $query1='';
  
           $data = TableRegistry::get('stores');       
           $query1 = $data->find('all')  
           ->select(['DISTINCT city_master.name','city_master.id']) 
          // ->where(['tbl_cart.current_cookie'=>$cookie])            
        //->order(['Categories.name' => 'ASC'])
        ->join([           
            'city_master' => [
                'table' => 'city_master',
                'type' => 'inner',
                'conditions' => 'city_master.id = stores.city and stores.active="1"'
            ]
        ]);
 
   if($query1->count()>0)
   {     
    return $query1; 
  }  
    else
    {    
     return null; 
    }

     
  }

  /********** for the pol content **********/
  public function getPledge()
  {
    $datay = TableRegistry::get('tb_pledge');
    $query = $datay->find()            
    ->where(['active'=>1])
     ->order(['created_date'=>'desc'])
    ->limit(1);
    return $query;
  }
  /********** for the pol content **********/
  public function getAllPledge()
  {
    $datay = TableRegistry::get('tb_pledge');
    $query = $datay->find()            
    ->where(['active'=>1])
     ->order(['created_date'=>'desc']);   
    return $query;
  }

  /************** for get polling status *************/
  function getpledgePolling($pledge_id)
  {

     $yesforsure    = TableRegistry::get('tbl_pledge_polls');
     $yesforsure    = $yesforsure->find()
             ->where(['tbl_pledge_id'=>$pledge_id,'polls'=>1])
             ->count();
    /**************** for May be *****************/
    $maybe    = TableRegistry::get('tbl_pledge_polls');
    $maybe = $maybe->find()
                 ->where(['tbl_pledge_id'=>$pledge_id,'polls'=>2])
                 ->count();
    /****************** for of course ******************/
    $ofcourse    = TableRegistry::get('tbl_pledge_polls');
    $ofcourse = $ofcourse->find()
                 ->where(['tbl_pledge_id'=>$pledge_id,'polls'=>3])
                 ->count();


    // echo  'forsute='.$yesforsure.' for may be= '.$maybe.' for of course='.$ofcourse;
    // echo '<br>';
    $total=$yesforsure+$maybe+$ofcourse;
    /************ get percentage *************/
    $yesforsure_per=floor(($yesforsure/$total)*100);
    $maybe_per=floor(($maybe/$total)*100);
    $ofcourse_per=floor(($ofcourse/$total)*100);
    return array('yesforsure_per'=>$yesforsure_per,'maybe_per'=>$maybe_per,'ofcourse_per'=>$ofcourse_per);
 }




}

?>