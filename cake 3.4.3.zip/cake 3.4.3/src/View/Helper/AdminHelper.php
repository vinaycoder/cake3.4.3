<?php
namespace App\View\Helper;
use Cake\View\Helper;
use Cake\ORM\TableRegistry;
class AdminHelper extends Helper
{
	public function adminProfile()
    {
             $datay = TableRegistry::get('login_admin');
             $queryy = $datay->find()            
                       ->where(['id'=>$this->request->session()->read('Auth.User.id')]);
             $typelist = array();
               foreach ($queryy as $roww)
                   {
                    $typelist = $roww;
                   }
                  return $typelist;               
    }
    public function queryCount()
    {
             $datay = TableRegistry::get('tblquery');
             $queryy = $datay->find()            
                       ->where(['unread'=>1])
                       ->count();
            return $queryy;
                           
    }
    public function newQueryList()
    {
      //ORDER BY date DESC LIMIT 5
      $record='';
      $url='';
      $datay = TableRegistry::get('tblquery');
             $queryy = $datay->find()
                      ->order(['date'=>'desc limit 5']);
                     
             foreach ($queryy as $key => $objRow) {
             $url= SITEURL.'admin/view-query-detail?id='.base64_encode($objRow['id']); 
            $record .= '<li>
                    <a href='.$url.' title="View detail of this Query">
                    <span class="subject">
                   <span class="from">'.$objRow['name'].' </span>
                   <span class="time">'.date('d M Y', $objRow['date']).' </span>
                  </span>
                  <span class="message">Contact Query</span>
                 </a>
               </li>';
             }
             return $record;

    }

}

?>