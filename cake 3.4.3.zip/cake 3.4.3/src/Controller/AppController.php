<?php
namespace App\Controller;
use Cake\Controller\Controller;
use Cake\Event\Event;

class AppController extends Controller
{

    
    public function initialize()
    {        
        $this->loadComponent('Flash');
        $this->loadComponent('Auth', [
            'authenticate' => [
            'Form' => [
            'fields' => [
            'username' => 'email',
            'password' => 'password'
            ]
            ]
            ],
            'loginAction'=>['controller'=>'Users','action'=>'login'],  //  define for auto redirect if not login
            'loginRedirect' => [                                       //  redirect after login
            'controller' => 'Home',
            'action' => 'index'
            ],
            'logoutAction'=>['controller'=>'Users','action'=>'logout'],  //  define for auto redirect for logout
            'logoutRedirect' => [                                        //  after logout redirect
            'controller' => 'Users',
            'action' => 'login'
            ],
            //'unauthorizedRedirect' => $this->referer() // If unauthorized, return

            ]);

            $action = strtolower($this->request->params['action']);
            $controller = strtolower($this->request->params['controller']);             
            $this->set('controller',$controller);
            $this->set('action',$action);
          

     }
    public function beforeFilter(Event $event)
    {       
       $this->viewBuilder()->setLayout('default');       
       $this->Auth->allow(['logout','login']);
       
    }

    public function beforeRender(Event $event)
    {
        if (!array_key_exists('_serialize', $this->viewVars) &&
            in_array($this->response->type(), ['application/json', 'application/xml'])
        ) {
            $this->set('_serialize', true);
        }
    }
   
}
