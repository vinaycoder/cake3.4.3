<?php
namespace App\Controller;
//namespace App\Controller\Admin;
use App\Controller\AppController;
use Cake\Event\Event;
class AdminController extends AppController
{
    public function beforeFilter(Event $event)
    {
         $this->Auth->config('authenticate', ['Form' => ['userModel' => 'LoginAdmin']]);
         $this->viewBuilder()->setLayout('admin');
    }
    public function initialize()
    {
        parent::initialize();
       // $this->loadComponent('Business');
        $this->LoadModel('LoginAdmin');
        
    }
    public function index()
    {
    	
    }
    public function myProfile()
    {
        
        
     $data=$this->LoginAdmin->get($this->request->session()->read('Auth.User.id'));
     $this->set('data',$data);
    }
  
    
}
