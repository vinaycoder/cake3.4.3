<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Core\Configure;

//use Cake\Mailer\Email;

use Cake\ORM\TableRegistry;

class AdminComponent extends Component
{

    public function adminProfile()
    {
        $datay = TableRegistry::get('login_admin');

        $queryy = $datay->find()

            ->where(['id' => $this->request->session()->read('Auth.User.id')]);

        $typelist = array();

        foreach ($queryy as $roww) {

            $typelist[$roww->id] = $roww->business_type;

        }

        return $typelist;

    }

    public function update($array = null, $table = null, $cond = null)
    {

        $data = array();

        $table = TableRegistry::get($table);

        $fields = $table->schema()->columns();

        unset($fields[0]); //  remove for id fields

        if (!empty($array)) {

            foreach ($array as $key => $value) {

                if (in_array($key, $fields)) {

                    //$fields2[]=$key;

                    $data[$key] = $value;

                }

            }

            $query = $table->query();

            $update = $query->update()->set($data)->where($cond)->execute();

            if ($update) {

                return true;

            } else {

                return false;

            }

        }

    }

    public function save($array = null, $table = null)
    {

        $datay = array();

        $table = TableRegistry::get($table);

        $fields = $table->schema()->columns();

        unset($fields[0]); //  remove for id fields

        unset($array['image']);

        $tabledata = $table->newEntity();

        if (!empty($array)) {

            foreach ($array as $key => $value) {

                if (in_array($key, $fields)) {

                    $data[$key] = $value;

                    $tabledata->$key = $value;

                }

            }

            $update = $table->save($tabledata);

            if ($update) {

                return true;

            } else {

                return false;

            }

        }

    }

    /*delete data from child table*/

    public function delete($table_name = null, $cound = null)
    {

        $moduleassocTable1 = TableRegistry::get($table_name);

        $query = $moduleassocTable1->query();

        $query->delete()

            ->where([$cound])

            ->execute();

        if ($query) {

            return true;

        } else {

            return false;

        }

    }

/*********************** getLastID  **********************************/

    public function lastid($table)
    {

        $data = TableRegistry::get($table);

        $queryqt = $data->find()

            ->limit(1)

            ->order(['id' => 'desc']);

        foreach ($queryqt as $key => $value) {

            return $value['id'];

        }

    }

    public function uploadImage($src = null, $path = null)
    {

        $image = $_FILES[$src]["name"];

        $tmpname = $_FILES[$src]["tmp_name"];

        if ($image) {

            $extension = $this->getExtension(stripslashes($image));

            $extension = strtolower($extension);

            if (($extension != "jpg") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {

                return array("error", "0");

            } else {

                $size = filesize($tmpname);

                if ($size > MAX_SIZE * 1024) {

                    return array("error", "0");

                } else {

                    $image = preg_replace("/[^a-zA-Z0-9.]/", "_", $image);

                    $file = strtolower(time() . '_' . $image);

                    move_uploaded_file($tmpname, $path . "$file");

                    //move_uploaded_file($tmpname, UPLOADABSPATH."images/$file");

                    return array("$file", "1");

                }

            }

        }

    }

    public function uploadFile($src = null, $path = null)
    {

        $image = $_FILES[$src]["name"];

        $tmpname = $_FILES[$src]["tmp_name"];

        if ($image) {

            $extension = $this->getExtension(stripslashes($image));

            $extension = strtolower($extension);

            // if (($extension != "xlsx") && ($extension != "jpeg") && ($extension != "png") && ($extension != "gif")) {

            //   return array("error", "0");

            // } else {

            $size = filesize($tmpname);

            if ($size > MAX_SIZE * 1024) {

                return array("error", "0");

            } else {

                $image = preg_replace("/[^a-zA-Z0-9.]/", "_", $image);

                $file = strtolower(time() . '_' . $image);

                move_uploaded_file($tmpname, $path . "$file");

                //move_uploaded_file($tmpname, UPLOADABSPATH."images/$file");

                return array("$file", "1");

            }

            // }

        }

    }

    public function getExtension($str)
    {

        $i = strrpos($str, ".");

        if (!$i) {return "";}

        $l = strlen($str) - $i;

        $ext = substr($str, $i + 1, $l);

        return $ext;

    }

    public function GetMonthsName()
    {

        $months = array(

            'January' => 'January',

            'February' => 'February',

            'March' => 'March',

            'April' => 'April',

            'May' => 'May',

            'June' => 'June',

            'July' => 'July',

            'August' => 'August',

            'September' => 'September',

            'October' => 'October',

            'November' => 'November',

            'December' => 'December',

        );

        return $months;

    }

    public function couponGenerate()
    {

        $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        $res = "";

        for ($i = 0; $i < 7; $i++) {

            $res .= $chars[mt_rand(0, strlen($chars) - 1)];

        }

        return $res;

    }

/*************************** resize image one by one    ************************************/

// $image_source_path=SITEURL.'webroot/image/1497426035_chart.png';

//$image_destination_path = WWW_ROOT.'1497426035_chart.png';

// resize_crop_image1(250, 250, $image_source_path, $image_destination_path);

    public function resize_crop_image1($max_width, $max_height, $source_file, $dst_dir, $quality = 100)
    {

        $imgsize = getimagesize($source_file);

        $width = $imgsize[0];

        $height = $imgsize[1];

        $mime = $imgsize['mime'];

        switch ($mime) {

            case 'image/gif':

                $image_create = "imagecreatefromgif";

                $image = "imagegif";

                break;

            case 'image/png':

                $image_create = "imagecreatefrompng";

                $image = "imagepng";

                $quality = 7;

                break;

            case 'image/jpeg':

                $image_create = "imagecreatefromjpeg";

                $image = "imagejpeg";

                $quality = 80;

                break;

            default:

                return false;

                break;

        }

        $dst_img = imagecreatetruecolor($max_width, $max_height);

        ///////////////

        imagealphablending($dst_img, false);

        imagesavealpha($dst_img, true);

        $transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);

        imagefilledrectangle($dst_img, 0, 0, $max_width, $max_height, $transparent);

        /////////////

        $src_img = $image_create($source_file);

        $width_new = $height * $max_width / $max_height;

        $height_new = $width * $max_height / $max_width;

        //if the new width is greater than the actual width of the image, then the height is too large and the rest cut off, or vice versa

        if ($width_new > $width) {

            //cut point by height

            $h_point = (($height - $height_new) / 2);

            //copy image

            imagecopyresampled($dst_img, $src_img, 0, 0, 0, $h_point, $max_width, $max_height, $width, $height_new);

        } else {

            //cut point by width

            $w_point = (($width - $width_new) / 2);

            imagecopyresampled($dst_img, $src_img, 0, 0, $w_point, 0, $max_width, $max_height, $width_new, $height);

        }

        $image($dst_img, $dst_dir, $quality);

        if ($dst_img) {
            imagedestroy($dst_img);
        }

        if ($src_img) {
            imagedestroy($src_img);
        }

    }

/****************** for image resize of (all image of a folder)  *****************/

    // $image_source_path=SITEURL.'webroot/image/1497426035_chart.png';

    //$image_destination_path = WWW_ROOT.'1497426035_chart.png';

    //$this->Admin->resize_crop_image(200, 200, $image_source_path, $image_destination_path);

    public function resize_crop_image($max_width, $max_height, $source_file, $dst_dir, $quality = 100)
    {

        $imgsize = getimagesize($source_file);

        $width = $imgsize[0];

        $height = $imgsize[1];

        $mime = $imgsize['mime'];

        switch ($mime) {

            case 'image/gif':

                $image_create = "imagecreatefromgif";

                $image = "imagegif";

                break;

            case 'image/png':

                $image_create = "imagecreatefrompng";

                $image = "imagepng";

                $quality = 7;

                break;

            case 'image/jpeg':

                $image_create = "imagecreatefromjpeg";

                $image = "imagejpeg";

                $quality = 80;

                break;

            default:

                return false;

                break;

        }

        $dst_img = imagecreatetruecolor($max_width, $max_height);

        ///////////////

        imagealphablending($dst_img, false);

        imagesavealpha($dst_img, true);

        $transparent = imagecolorallocatealpha($dst_img, 255, 255, 255, 127);

        imagefilledrectangle($dst_img, 0, 0, $max_width, $max_height, $transparent);

        /////////////

        $src_img = $image_create($source_file);

        $width_new = $height * $max_width / $max_height;

        $height_new = $width * $max_height / $max_width;

        //if the new width is greater than the actual width of the image, then the height is too large and the rest cut off, or vice versa

        if ($width_new > $width) {

            //cut point by height

            $h_point = (($height - $height_new) / 2);

            //copy image

            imagecopyresampled($dst_img, $src_img, 0, 0, 0, $h_point, $max_width, $max_height, $width, $height_new);

        } else {

            //cut point by width

            $w_point = (($width - $width_new) / 2);

            imagecopyresampled($dst_img, $src_img, 0, 0, $w_point, 0, $max_width, $max_height, $width_new, $height);

        }

        $image($dst_img, $dst_dir, $quality);

        if ($dst_img) {
            imagedestroy($dst_img);
        }

        if ($src_img) {
            imagedestroy($src_img);
        }

    }

    public function slug($title)
    {

        // replace non letter or digits by -

        $url = preg_replace('~[^\\pL\d]+~u', '-', $title);

        // trim url

        $url = trim($url, "-");

        // lowercase url

        $url = strtolower($url);

        // remove unwanted characters

        $url = preg_replace('~[^-\w]+~', '', $url);

        //Add timestamp to url for preventing duplicacy

        //$url = $url."-".time();

        // return url to function.

        return $url;

    }

    public function findAll($table, $cond)
    {
        $obj = '';

        $data = TableRegistry::get($table);

        $queryqt = $data->find()

            ->where($cond);

        if (!empty($queryqt)) {

            foreach ($queryqt as $key => $value) {

                $obj[] = $value;

            }

            return $obj;

        } else {

            return null;

        }
    }
    public function getSeoPage($type = null)
    {
        $datafasd = array();
        $data = TableRegistry::get('tbl_pages');
        $queryqt = $data->find()
            ->order(['page_name' => 'asc']);
        foreach ($queryqt as $key => $value) {
            $datafasd[$value->id] = $value->page_name;
        }
        return $datafasd;

    }
    public function checkSavepage($id)
    {
        $datafasd = array();
        $data = TableRegistry::get('tbl_page_seo');
        $queryqt = $data->find()
            ->order(['page_name' => 'asc']);

    }
    public function updateCart($cookie = null, $user_id = null)
    {
        $users = TableRegistry::get('tbl_cart');
        $query = $users->query();
        $query->update()
            ->set(['user_id' => $user_id])
        // ->where(['current_cookie' => $cookie,'user_id IS'=>null,'del'=>'0','coupon_id'=>'','coupon_code'=>''])
            ->where(['current_cookie' => $cookie, 'user_id IS' => null, 'del' => '0'])
            ->execute();
    }
    public function ViewCart($cookie = null, $user_id = null)
    {
        $objDetail = '';
        if (isset($_SESSION['u_user_id'])) {
            if (!empty($user_id)) {
                $data = TableRegistry::get('tbl_cart');
                $query1 = $data->find('all')
                    ->group(['product_id'])
                    ->select(['tbl_cart.id', 'tbl_cart.coupon_id', 'tbl_cart.coupon_code', 'tbl_cart.product_id', 'tbl_cart.quantity', 'tbl_cart.category_id', 'category.name', 'tbl_cart.current_cookie', 'tbl_cart.user_id', 'tbl_cart.add_time', 'products.name', 'products.code', 'products.price', 'products.price2', 'products.stock', 'products.pieces', 'products.description', 'products.weight'])
                // ->where(['tbl_cart.current_cookie'=>$cookie])
                //->order(['Categories.name' => 'ASC'])
                    ->join([
                        'products' => [
                            'table' => 'products',
                            'type' => 'inner',
                            'conditions' => 'products.id = tbl_cart.product_id and tbl_cart.user_id="' . $user_id . '" and tbl_cart.del="0"',
                        ],
                        'category' => [
                            'table' => 'category',
                            'type' => 'inner',
                            'conditions' => 'category.id = products.category',
                        ],
                    ]);

            }
        } else {
            if (!empty($cookie)) {
                $data = TableRegistry::get('tbl_cart');
                $query1 = $data->find('all')
                    ->group(['product_id'])
                    ->select(['tbl_cart.id', 'tbl_cart.coupon_id', 'tbl_cart.coupon_code', 'tbl_cart.product_id', 'tbl_cart.quantity', 'tbl_cart.category_id', 'category.name', 'tbl_cart.current_cookie', 'tbl_cart.user_id', 'tbl_cart.add_time', 'products.name', 'products.code', 'products.price', 'products.price2', 'products.stock', 'products.pieces', 'products.description', 'products.weight'])
                // ->where(['tbl_cart.current_cookie'=>$cookie])
                //->order(['Categories.name' => 'ASC'])
                    ->join([
                        'products' => [
                            'table' => 'products',
                            'type' => 'inner',
                            'conditions' => 'products.id = tbl_cart.product_id and tbl_cart.current_cookie="' . $cookie . '" and tbl_cart.del="0" and tbl_cart.user_id IS NULL',
                        ],
                        'category' => [
                            'table' => 'category',
                            'type' => 'inner',
                            'conditions' => 'category.id = products.category',
                        ],
                    ]);

                //prd('vinay');

            }
        }
        return $query1;
    }

}
