<?php
namespace App\Controller\Admin;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Auth\DefaultPasswordHasher; //include this line
use Cake\Mailer\Email;
class HomeController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Admin');            
        $this->LoadModel('LoginAdmin');       
    }
    public function index()
    {
    
    }
    

}
