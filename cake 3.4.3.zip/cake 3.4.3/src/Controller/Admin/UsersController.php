<?php
namespace App\Controller\Admin;
use App\Controller\AppController;
use Cake\Auth\DefaultPasswordHasher; //include this line
use Cake\Event\Event;

class UsersController extends AppController
{
	public function beforeFilter(Event $event)
    {

     	 $this->Auth->config('authenticate', ['Form' => ['userModel' => 'LoginAdmin']]);
    }

    public function index()
    {

    }
    public function login()
    { 

        //checking if user is already logged in
        if($this->Auth->User())
        {
            $this->_checkExistingLogin();
        }
        else
        {
           
            if ($this->request->is(['post','POST'])) {                
                $user = $this->Auth->identify();  

                if ($user) { 
                     // print_r($this->Auth->identify());   
                     // die; 
                    $user['login_time'] = date('M d Y H:i:s');
                    $user['type'] = 'admin';
                    $this->Auth->setUser($user);
                    // $this->Flash->success(__(SYSTEM_MESSAGE_VALID_LOGIN));
                    return $this->redirect($this->Auth->redirectUrl());
                    
                   
                    /* insert into user log table*/
                   // $this->Business->userlog('admin',$user['id']);
                   
                    //////  check privilege
                    //$tt=$this->Business->getadminprivilege($user['group_id']);                   
                    
                   // $this->request->session()->Write('User.AllowedActions',$tt);
                    // end privilege
                   
                   
                    
                }
                else
                {                      
                        $this->Flash->error(__(SYSTEM_MESSAGE_INVALID_LOGIN));                    
                }
            }

            
        }


    }

    public function add()
    {

    }
    public function logout()
    {
    	$this->Flash->success(__('You have successfully logout'));
    	return $this->redirect($this->Auth->logout());
    }

    protected function _checkExistingLogin()
    {        
        return $this->redirect($this->Auth->redirectUrl());
    }

    
    public function edit($id=null,$page=null)
    {
        $user = $this->Users->get(base64_decode($id));
        
        if ($this->request->is(['post', 'put']))
        {
            $this->Users->patchEntity($user, $this->request->data,['validate' => 'update']);
            if(isset($this->request->data['password1']) && !empty($this->request->data['password1']))
            {
                $user = $this->Users->patchEntity($user, ['password' => $this->request->data['password1']]);
            }
            $user->set(
                $this->Common->setDefaultAttributeUpdate($this->Auth->user('id'))
            );
            if ($this->Users->save($user)) {
                $this->Flash->success(__(SYSTEM_MESSAGE_RECORD_UPDATED));
                return $this->redirect(['action' => 'index'.$user->page]);
            }
            else
            {
                $this->_loadEditMaster($user);
                $this->Flash->error(__(SYSTEM_MESSAGE_RECORD_UPDATE_ERROR));
            }
        }
        elseif(isset($id) & !empty($id))
        {
            $user->password = "";
            $this->_loadEditMaster($user);
        }
        else
        {
            $this->Flash->error(__(SYSTEM_MESSAGE_RECORD_INVALID));
            return $this->redirect(['action' => 'index']);
        }
        $this->set('user', $user);
    }

    
}
