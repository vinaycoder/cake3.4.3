<?php
namespace App\Controller;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Auth\DefaultPasswordHasher; //include this line
use Cake\Mailer\Email;
class AjaxController extends AppController
{
	  public function beforeFilter(Event $event)
    {
        $this->Auth->allow(['savecart','deletecart','cartupdate','checkpincode','applycoupon','deleteCoupon','order','register','shipping','newletter','contact','fileupload','sorting','polls','ordercanceluser']);        
    }
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Admin');
        $this->loadComponent('Mail');
        $this->loadComponent('Ecom');        
        $this->LoadModel('LoginAdmin');
    }

public function savecart()
{	

 error_reporting(0);
if(!empty($this->request->data['product_id']))
 {
  $cookie='';
  $objCount='';
  if($this->request->session()->read('u_user_id')!='')
  {
     
        $data = TableRegistry::get('tbl_cart');
        $queryqt = $data->find()
                  ->where(['product_id '=>$this->request->data['product_id'],'user_id'=>$this->request->session()->read('u_user_id'),'del'=>'0'])
                  ->count(); 
       $objCount=  $queryqt;          
  }
  else
  {
    if(isset($_COOKIE['cart_value_cookies'])) 
      {
         $cookie=$this->Ecom->getCookie();       
         $data = TableRegistry::get('tbl_cart');
         $queryqt = $data->find()
                  ->where(['product_id '=>$this->request->data['product_id'],'current_cookie'=>$cookie,'user_id'=>' ','del'=>'0'])
                  ->count();
         $objCount=  $queryqt; 
                
      }

  }

  if($objCount<1)
  {  
  $formData['product_id']        =$this->request->data['product_id'];  
  $formData['add_time']          =time(); 
  $formData['category_id']       =$this->request->data['cat_id'];
  //$formData['product_name']      ='Test';   
  //$formData['total_price']       =500;
  $formData['quantity']          =1;
  $formData['ip_address']        =$_SERVER['REMOTE_ADDR'];
  $formData['current_cookie']    =$cookie;  
  $formData['user_id']           =$this->request->session()->read('u_user_id'); 

  $response= $this->Admin->save($formData,$table='tbl_cart'); 
 // pr($response);
  // prd($formData); 
  if($response)
    {
     // $pro_id=lastid('tbl_cart');
      $total_cart_value=$this->Ecom->cartValue($cookie=$cookie,$user_id=$formData['user_id']);      
      $output_array=array('status'=>'add','total_cart_item'=>$total_cart_value);
      echo json_encode($output_array); 
      $this->autoRender = false;    
    }
    else
    {
      $output_array=array('status'=>'fail','total_cart_item'=>'');
      echo json_encode($output_array);
      $this->autoRender = false; 
      
    }
  
  }
  else
  {
    $output_array=array('status'=>'old','total_cart_item'=>'');
      echo json_encode($output_array);
      $this->autoRender = false;
    
  }
}
$this->autoRender = false;

}
public function deletecart()
{	
$del= $this->Admin->update(['del'=>'1'],'tbl_cart','id='.$this->request->data['cart_id']);
	if($del)
	{
		echo 'delete';
	}
	else
	{
		echo 'fail';
	}
	$this->autoRender = false;
}
public function cartupdate()
{
   //$del= $this->Admin->update(['quantity'=>$this->request->data['qty']],'tbl_cart','id='.$this->request->data['cart_id']);
   $del= $this->Admin->update(['quantity'=>$this->request->data['qty'],'coupon_id'=>'','coupon_code'=>''],'tbl_cart','id='.$this->request->data['cart_id']);
	if($del)
	{
		echo 'update';
	}
	else
	{
		echo 'fail';
	}
	$this->autoRender = false;
}
public function checkpincode()
{
  error_reporting(0);
  $value1='';
           $data = TableRegistry::get('pincode_locator');
        $queryqt = $data->find()
                  ->where(['pincode '=>$this->request->data['pincode'],'active'=>'1']);
                  //->count(); 
 foreach ($queryqt as $key => $value) {
   $value1=$value;
 }
 //prd($value['cod']);
// prd($value['pincode']);
	if($value1['cod']=='Y' && $value1['pincode']!='')
	{
    $status='updatecod';		
	}
  else if($value1['cod']=='N' && $value1['pincode']!='')
  {
    $status='update';   
  }
	else
	{
    $status='fail';		
	}
  $output_array=array('status'=>$status,'order_id'=>'122');
  echo json_encode($output_array);
  die;
	$this->autoRender = false;
}
/***********  for coupon apply  ****************/
public function applycoupon()
{
	error_reporting(0);
	/*getting cart value*/
	//session_start();
	//prd($this->request->data);
	  if($this->request->session()->read('u_user_id')!='')
        {
            $user_id=$this->request->session()->read('u_user_id');
        }
        else
        {
            $user_id=null;
        }
        $cookie_value_card=$this->Ecom->getCookie();
        $cart_value =$this->Ecom->ViewCart($cookie=$cookie_value_card,$user_id=$user_id);
    
	if(!empty($this->request->data['coupon_code']))
     {	
     	$current_date=date('Y-m-d');
     	$coupon_data=$this->Admin->findAll('coupon_codes',array('code'=>$this->request->data['coupon_code'],'active'=>1,'start_date <='=>$current_date,'end_date >='=>$current_date));
     	
     	if(!empty($coupon_data))
     	{
        /************** validation for only one quantity **************/
                    /************ validate only 5000 order on coupon ***********/
                      $check_all_orders=$this->Admin->findAll('tbl_order_details',array('status'=>'success'));
                        if(!empty($check_all_orders))
                        {
                          foreach ($check_all_orders as $key20255 => $value20255) {  
                            $total_order_item[]=$value20255;            
                        }            
                          if(count($total_order_item)>500)
                          {
                              echo 'morethanfive';
                              die;
                          }                         
                      }
       /**************** second validation for only one packs  ***************/
            if(!empty($cart_value))
            {
              foreach ($cart_value as $key2025 => $value2025) {  
                $cart_quantity[]=$value2025;            
            }            
              if(count($cart_quantity)>1)
              {
                  echo 'morethanone';
                  die;
              }
              else
              {
                if($cart_quantity[0]['quantity']>1)
                {
                  echo 'morethanone';
                  die;
                } 
                else{
                  if($cart_quantity[0]['product_id']==4)
                  {

                  }
                  else
                  {
                    echo 'onlyonepack';
                    die;

                  }
                }            
              }
            
            }
           
            /*********** end validation *************/
     		
     		if($coupon_data[0]['single_unlimited_use']=='1')
     		{

          if(!empty($cart_value))
          {
            foreach ($cart_value as $key => $value) {                    
            $formData['coupon_id']=$coupon_data[0]['id'];
            $formData['coupon_code']=$coupon_data[0]['code'];
            $others= $this->Admin->update($formData,'tbl_cart','id='.$value['id']);
            }
            if($others){
            echo 'successsingle';
            die;
          }else{
            echo 'failone';
            die;
          }
          }
          else
          {
            echo 'nfound';
            die;
          }
          //prd($coupon_data);
     		}
     		else
     		{

          //prd($coupon_data);
           if($this->request->session()->read('u_user_id')!='')
            {
              $check_old_coupon=$this->Admin->findAll('tbl_order_master',array('coupon_id'=>$coupon_data[0]['id'],'user_id'=>$this->request->session()->read('u_user_id')));
            }
            else
            {
              $check_old_coupon=$this->Admin->findAll('tbl_order_master',array('coupon_id'=>$coupon_data[0]['id'],'current_cookie'=>$cookie_value_card));
            }
            if(empty($check_old_coupon))
            {
              if(!empty($cart_value))
              {
                foreach ($cart_value as $key => $value) {               
                  $formData['coupon_id']=$coupon_data[0]['id'];
                  $formData['coupon_code']=$coupon_data[0]['code'];
                  $others= $this->Admin->update($formData,'tbl_cart','id='.$value['id']);
                }
                if($others){
                  echo 'successsingle';
                  die;
                }else{
                  echo 'failone';
                  die;
                }
              }
              else
              {
                echo 'nfound';
                die;
              }

            }else
            {
              echo 'old';
              die;
            }

     		}
     	}
     	else
     	{
     		echo 'nfound';
        die;
     	}
     	//prd($coupon_data);
		
     }
     else
     {
     	echo 'nfound';
      die;
     }
$this->autoRender = false;

}
public function deleteCoupon()
{
	error_reporting(0);
	/*getting cart value*/
	//session_start();
	//prd($_SESSION);
	  if($this->request->session()->read('u_user_id')!='')
        {
            $user_id=$this->request->session()->read('u_user_id');
        }
        else
        {
            $user_id=null;
        }
        $cookie_value_card=$this->Ecom->getCookie();
        $cart_value =$this->Ecom->ViewCart($cookie=$cookie_value_card,$user_id=$user_id);
    
	if(!empty($this->request->data['coupon_code']))
     {	
     		if(!empty($cart_value))
     			{
     				foreach ($cart_value as $key => $value) {     					
     					$formData['coupon_id']='';
						$formData['coupon_code']='';
						$others= $this->Admin->update($formData,'tbl_cart','id='.$value['id']);
     				}
     				if($others){
						echo 'successsingle';
					}else{
						echo 'failone';
					}
     			}
     			else
     			{
     				echo 'nfound';
     			}
		
     }
     else
     {
     	echo 'nfound';
     }
$this->autoRender = false;
}
/*************** save order ********************/
public function order()
{
  $cities=$this->Ecom->getCity();
  $pincode=$this->Ecom->getPincode();
  if ($this->request->is(['post','POST']))
    {
      if($this->request->session()->read('u_user_id')!='' && $this->request->data['total_pay'])
      {
       // prd($this->request->data);
        $order_no1=substr(time(),5,10);
        $order_no=$this->request->session()->read('u_user_id').$order_no1;
        $this->request->data['order_number']=$order_no;
        $this->request->data['tax_id']=$this->request->data['tax_id'];
        $this->request->data['tax_value']=$this->request->data['tax_value'];
        $this->request->data['tax_rate']=$this->request->data['tax_rate'];
        $this->request->data['coupon_id']=$this->request->data['coupon_id'];
        $this->request->data['coupon_code']=$this->request->data['coupon_code'];
        $this->request->data['coupon_value']=$this->request->data['coupon_value'];
        $this->request->data['shipping_charge']=$this->request->data['shipping_charge'];
        $this->request->data['total']=$this->request->data['total_pay'];
        $this->request->data['total_amt_without_tax']=$this->request->data['total_amt'];
        $this->request->data['ip_address']=$_SERVER['REMOTE_ADDR'];;
        $this->request->data['user_id']=$this->request->session()->read('u_user_id');        
        $this->request->data['first_name']=$this->request->session()->read('u_name');
        $this->request->data['email']=$this->request->session()->read('u_email');
        $this->request->data['trans_no']=$this->request->data['trans_no'];

        $this->request->data['shiping_city']=$this->request->data['shipping_city'];
        $this->request->data['shiping_locality']=$this->request->data['shipping_locality'];
        $this->request->data['shiping_pincode']=$this->request->data['shipping_pincode'];
        $this->request->data['shiping_address']=$this->request->data['shipping_address'];
        $this->request->data['shiping_city_name']=$cities[$this->request->data['shipping_city']];
        $this->request->data['shiping_pincode_name']=$this->request->data['shipping_pincode'];
        $this->request->data['shipping_phone']=$this->request->data['shipping_phone'];

       $this->request->data['billing_city']=$this->request->data['billing_city'];
        $this->request->data['billing_locality']=$this->request->data['billing_locality'];
        $this->request->data['billing_pincode']=$this->request->data['billing_pincode'];
        $this->request->data['billing_address']=$this->request->data['billing_address'];
        $this->request->data['billing_city_name']=$cities[$this->request->data['billing_city']];
        $this->request->data['billing_pincode_name']=$this->request->data['billing_pincode'];
        $this->request->data['billing_phone']=$this->request->data['billing_phone'];
        $this->request->data['current_cookie']=$this->request->data['current_cookie'];
        $this->request->data['order_date']=time();
        //prd($this->request->data);
        $response= $this->Admin->save($this->request->data,$table='tbl_order_master');          
        $last_id= $this->Admin->lastid($table='tbl_order_master');
        if($response)
        { 
           $this->request->session()->write('shipping_city',$this->request->data['shipping_city']);
           $this->request->session()->write('shiping_locality',$this->request->data['shipping_locality']);
           $this->request->session()->write('shiping_pincode',$this->request->data['shipping_pincode']);
           $this->request->session()->write('shiping_address',$this->request->data['shipping_address']);
           $this->request->session()->write('shipping_phone',$this->request->data['shipping_phone']);

           $this->request->session()->write('billing_city',$this->request->data['billing_city']);            
           $this->request->session()->write('billing_locality',$this->request->data['billing_locality']);
           $this->request->session()->write('billing_pincode',$this->request->data['billing_pincode']);
           $this->request->session()->write('billing_address',$this->request->data['billing_address']);
           $this->request->session()->write('billing_phone',$this->request->data['billing_phone']);
           $formData1['shiping_city']=$this->request->data['shiping_city'];
           $formData1['shiping_locality']=$this->request->data['shiping_locality'];
           $formData1['shiping_pincode']=$this->request->data['shiping_pincode'];
           $formData1['shiping_address']=$this->request->data['shiping_address'];
           $this->Admin->update($formData1,'tblusers','id='.$this->request->session()->read('u_user_id'));
        foreach ($this->request->data['cart_id'] as $key => $value) {
          if(!empty($value))
          {
             $formData['order_id']=$last_id;
             $formData['product_id']=$this->request->data['product_id'][$key];
             $formData['product_name']=$this->request->data['product_name'][$key];
             $formData['quatity']=$this->request->data['quatity'][$key];
             $formData['product_image']=$this->request->data['product_image'][$key];
             $formData['category_id']=$this->request->data['category_id'][$key];
             $formData['category_name']=$this->request->data['category_name'][$key];
             $formData['mrp']=$this->request->data['mrp'][$key];
             $formData['price']=$this->request->data['price'][$key];
             $formData['total']=$this->request->data['quatity'][$key]*$this->request->data['price'][$key];
             $formData['cart_id']=$this->request->data['cart_id'][$key];
             $response2= $this->Admin->save($formData,$table='tbl_order_details'); 
             $mailProductName=$formData['product_name'].' '.$formData['category_name'];
             $products[]=array('product_image'=>$formData['product_image'],'product_name'=>$mailProductName,'price'=>$formData['price'],'quantity'=>$formData['quatity'],'total'=>$formData['total']); 

          }  
        }
          if($response2)
          {
            /*for tax name */
            if($this->request->data['shiping_city']==325 || $this->request->data['shiping_city']==6)
            {
              $tax_city='delhi';
            }
            else
            {
              $tax_city='other';

            }
            if($this->request->data['shipping_charge']=='' || $this->request->data['shipping_charge']==0)
            {
              $this->request->data['shipping_charge']='free';
            }
            $this->Mail->OrderSucess($products,array('name'=>$this->request->session()->read('u_name'),'email'=>$this->request->session()->read('u_email'),'total'=>$this->request->data['total_amt'],'gross_total'=>$this->request->data['total_pay'],'shipping'=>$this->request->data['shipping_charge'],'order_no'=>$order_no,'tax'=>$this->request->data['tax_value'],'coupon'=>$this->request->data['coupon_value'],'tax_city'=>$tax_city));
                $output_array=array('status'=>'add','order_id'=>$order_no);
                echo json_encode($output_array); 
                die;
          }
          

        }



      }
      else
      {
        $output_array=array('status'=>'fail');
        echo json_encode($output_array);
        die;
      }
      
    }
    $this->autoRender = false;

}
public function shipping()
{
  if ($this->request->is(['post','POST']))
        {         
          if($this->request->data['city']!='')
          {
              $shipping_data=$this->Admin->findAll('shippings',array('city'=>$this->request->data['city'],'active'=>1));
              if(empty($shipping_data))
              {
                 echo 'nfound';
                    die;
              }
              // prd($shipping_data);
               if($this->request->session()->read('u_user_id')!='')
                {
                    $user_id=$this->request->session()->read('u_user_id');
                }
                else
                {
                    $user_id=null;
                }
                $cookie_value_card=$this->Ecom->getCookie();
                $cart_value =$this->Ecom->ViewCart($cookie=$cookie_value_card,$user_id=$user_id);
                  if(!empty($cart_value))
                  {
                    foreach ($cart_value as $key => $value) {               
                      $formData['shipping_id']=$shipping_data[0]['id'];
                    $formData['shipping_amt']=$shipping_data[0]['shipping_price'];
                    $others= $this->Admin->update($formData,'tbl_cart','id='.$value['id']);
                    }
                    if($others){
                      $this->request->session()->write('shipping_city',$this->request->data['city']);
                      $this->Admin->update(array('shiping_city'=>$this->request->data['city']),'tblusers','id='.$this->request->session()->read('u_user_id'));
                    echo 'success';
                    die;
                  }else{
                    echo 'fail';
                    die;
                  }
                  }
                  else
                  {
                    echo 'nfound';
                    die;
                  }
          }
        }

}
public function register()
{
	    if ($this->request->is(['post','POST']))
        {
          /****************** for google login *****************************************************************/

          if($this->request->data['login_from']=='google')
          {
             if($this->request->data['email']!='' && $this->request->data['google_id']!='')
             {
               $data    = TableRegistry::get('tblusers');
               $queryqt = $data->find()
                        ->where(['email'=>$this->request->data['email'],'active'=>'1','google_id !='=>'','google_id IS NOT'=>null]);
               if($queryqt->count()>0)
               {
                  foreach ($queryqt as $key => $value)
                   {                   
                   $session_time = 5*60;
                   $this->request->session()->write('u_user_id',$value['id']);
                   $this->request->session()->write('u_email',$value['email']);
                   $this->request->session()->write('u_name',$value['name']);
                   $this->request->session()->write('google_id',$value['google_id']);
                   $this->request->session()->write('login_from','google');
                   $this->request->session()->write('u_time',time() + $session_time);  
                   $this->request->session()->write('shipping_city',$value['shiping_city']);
                   $this->request->session()->write('shiping_locality',$value['shiping_locality']);
                   $this->request->session()->write('shiping_pincode',$value['shiping_pincode']);
                   $this->request->session()->write('shiping_address',$value['shiping_address']);                          
                  }
                  echo json_encode(array('status'=>'success'));
                  die;
               }
               else
               {
                  $this->request->data['created_date']=time();
                  $response= $this->Admin->save($this->request->data,$table='tblusers');          
                  $last_id= $this->Admin->lastid($table='tblusers');
                  if($response)
                  {                  
                   $session_time = 5*60;
                   $this->request->session()->write('u_user_id',$last_id);
                   $this->request->session()->write('u_email',$this->request->data['email']);
                   $this->request->session()->write('u_name',$this->request->data['name']);
                   $this->request->session()->write('google_id',$this->request->data['google_id']);
                   $this->request->session()->write('login_from','google');
                   $this->request->session()->write('u_time',time() + $session_time);
                   $this->request->session()->write('shipping_city','');
                   $this->request->session()->write('shiping_locality','');
                   $this->request->session()->write('shiping_pincode','');
                   $this->request->session()->write('shiping_address','');
                   echo json_encode(array('status'=>'success'));
                    die;
                  }
                 else
                 {
                  echo json_encode(array('status'=>'fail'));
                      die;
                 }

               }

             }
             else
             {
              echo json_encode(array('status'=>'noemail'));
                  die;
             }
          }
     /********************************* end here for the google login   ******************************************/

     /********************************* using for facebook login  *****************************************/
     if($this->request->data['login_from']=='facebook')
          {
            if($this->request->data['email']!='' && $this->request->data['facebook_id']!='')
            {
             $data    = TableRegistry::get('tblusers');
             $queryqt = $data->find()
             ->where(['email'=>$this->request->data['email'],'active'=>'1','facebook_id !='=>'','facebook_id IS NOT'=>null]);
             if($queryqt->count()>0)
             {
              foreach ($queryqt as $key => $value)
              {          
               $this->request->session()->write('u_user_id',$value['id']);
               $this->request->session()->write('u_email',$value['email']);
               $this->request->session()->write('u_name',$value['name']);
               $this->request->session()->write('facebook_id',$value['facebook_id']);
               $this->request->session()->write('login_from','facebook');
               $this->request->session()->write('u_time',time() + $session_time);                 
          }
          echo json_encode(array('status'=>'success'));
          die;
          }
          else
          {
              $this->request->data['created_date']=time();
              $response= $this->Admin->save($this->request->data,$table='tblusers');          
              $last_id= $this->Admin->lastid($table='tblusers');
              if($response)
              {                  
               $session_time = 5*60;
               $this->request->session()->write('u_user_id',$last_id);
               $this->request->session()->write('u_email',$this->request->data['email']);
               $this->request->session()->write('u_name',$this->request->data['name']);
               $this->request->session()->write('facebook_id',$this->request->data['facebook_id']);
               $this->request->session()->write('login_from','facebook');
               $this->request->session()->write('u_time',time() + $session_time);
               echo json_encode(array('status'=>'success'));
                die;
              }
             else
             {
              echo json_encode(array('status'=>'fail'));
                  die;
             }
          }

            }
            else
            {
              echo json_encode(array('status'=>'noemail'));
              die;
            }
            }
   /********************************** end here for facebook login   ************************************/          
        }	}
  public function newletter()
  {
    if ($this->request->is(['post','POST']))
    {
     // prd($this->request->data);
      $old_data=$this->Admin->findAll('subscribrd_emails',array('email'=>$this->request->data['email']));
      if(empty($old_data))
      {
        $this->request->data['created_date']=date('Y-m-d');
        $response= $this->Admin->save($this->request->data,$table='subscribrd_emails'); 
        if($response)
        {             
          $this->Mail->NewsLetterMail(array('email'=>'vinay@radicalreflex.com')); 
          $this->Mail->NewsLetterMailAdmin(array('email'=>'vinay@radicalreflex.com')); 
          echo 'success';
          die;
        }
        else
        {
          echo 'fail';
          die;

        }
      }
      else
      {
        echo 'old';
        die;
      }
    }
    $this->autoRender = false;
  }

  public function contact()
  {
    //prd($this->request->data);
    if($this->request->data['name']!='' && $this->request->data['email']!='' && $this->request->data['phone']!='' && $this->request->data['message']!='')
    {
      $this->request->data['date']=time();
      $this->request->data['ip']=$_SERVER['REMOTE_ADDR'];;
      $response= $this->Admin->save($this->request->data,$table='tblquery'); 
      if($response)
      {        
       $this->Mail->contactMailToAdmin($this->request->data); 
       $this->Mail->contactMailToUser($this->request->data);
       echo 'successsingle';
       die;
      }
    }
    else
    {
      echo 'fail';
      die;
    }
     die;
  }

  public function fileupload()
  {
    $options = array(
    'delete_type' => 'POST',
    'upload_dir' => MULTIMGAGE
);
    require_once(ROOT . DS  . 'vendor' . DS  . 'fileupload'  . DS . 'index.php');
    //include(ROOT.'\vendor\fileupload\index.php');
    $upload_handler = new \ CustomUploadHandler($options);
   // $mpdf=new \ mPDF('c');
    //prd($upload_handler);
    die;
  }

  public function sorting()
  {
    if (isset($this->request->data['orders'])){
    $orders = explode('&', $this->request->data['orders']);
    $array = array();
        foreach($orders as $item) 
        {
        $item = explode('=', $item);        
        $array[] = $item[1];
        }
        /***************  for category features  **************/
        if (isset($this->request->data['type']) && $this->request->data['type']=='category')
        {
        //  prd($array);
          if(!empty($array))
          {
            foreach($array as $key => $value)
              {
                $this->Admin->update(['orders'=>$key],'category','id='.$value);               
              }
              echo "success";
           }
        }
        /**********************  for category utility  ************************/
        if (isset($this->request->data['type']) && $this->request->data['type']=='sectors')
        {
          if(!empty($array))
          {
            foreach($array as $key => $value)
              {
                $this->Admin->update(['orders'=>$key],'category_sectors','id='.$value);
               // updateData(array('orders'=>$key),$table_name='tbl_category',$cond="id=".$value);
              }
              echo "success";
           }
        }
               /**********************  for category faq  ************************/
        if (isset($this->request->data['type']) && $this->request->data['type']=='product')
        {
          if(!empty($array))
          {
            foreach($array as $key => $value)
              {
                $this->Admin->update(['orders'=>$key],'products','id='.$value);
               // updateData(array('orders'=>$key),$table_name='tbl_category',$cond="id=".$value);
              }
              echo "success";
           }
        }


    }
    die;
  }
 
 public function polls()
 {
     $iptest    = TableRegistry::get('tbl_pledge_polls');
     $iptest    = $iptest->find()
               ->where(['tbl_pledge_id'=>$this->request->data['pleadge_id'],'ip_address'=>$_SERVER['REMOTE_ADDR']])
               ->count();
    if($iptest>0)
    {
        $output_array=array('status'=>'old');
        echo json_encode($output_array);   
        die;

    }

  $formData['tbl_pledge_id']        =$this->request->data['pleadge_id'];  
  $formData['polls']                =$this->request->data['poll'];  
  $formData['created_date']         =date('Y-m-d');  
  $formData['ip_address']           =$_SERVER['REMOTE_ADDR'];  
  $response= $this->Admin->save($formData,$table='tbl_pledge_polls');
  if($response)
  {
   
     $yesforsure    = TableRegistry::get('tbl_pledge_polls');
     $yesforsure    = $yesforsure->find()
             ->where(['tbl_pledge_id'=>$this->request->data['pleadge_id'],'polls'=>1])
             ->count();
/**************** for May be *****************/
$maybe    = TableRegistry::get('tbl_pledge_polls');
$maybe = $maybe->find()
             ->where(['tbl_pledge_id'=>$this->request->data['pleadge_id'],'polls'=>2])
             ->count();
/****************** for of course ******************/
$ofcourse    = TableRegistry::get('tbl_pledge_polls');
$ofcourse = $ofcourse->find()
             ->where(['tbl_pledge_id'=>$this->request->data['pleadge_id'],'polls'=>3])
             ->count();


// echo  'forsute='.$yesforsure.' for may be= '.$maybe.' for of course='.$ofcourse;
// echo '<br>';
$total=$yesforsure+$maybe+$ofcourse;

/************ get percentage *************/
$yesforsure_per=floor(($yesforsure/$total)*100);
$maybe_per=floor(($maybe/$total)*100);
$ofcourse_per=floor(($ofcourse/$total)*100);
$status='success';
  }
  else
  {
    $status='fail';   
  }
  $output_array=array('status'=>$status,'yesforsure'=>$yesforsure_per,'maybe_per'=>$maybe_per,'ofcourse_per'=>$ofcourse_per);
  echo json_encode($output_array);   
  //prd($this->request->data);
  die;

 }
 public function ordercanceluser()
 {
  //prd($this->request->data);
   $del= $this->Admin->update(['order_action_user'=>$this->request->data['action'],'order_notification'=>'Your order has been cancelled','order_status'=>'Cancelled'],'tbl_order_master','id='.$this->request->data['order_id']);
    if($del)
    {
     $order_data=$this->Admin->findAll('tbl_order_master',array('id'=>$this->request->data['order_id']));
       $this->Mail->OrderCancelledMail(array('name'=>$this->request->session()->read('u_name'),'email'=>$this->request->session()->read('u_email'),'order_no'=>$order_data[0]['order_number']));
      echo 'update';
    }
    else
    {
      echo 'fail';
    }
    $this->autoRender = false;

 }
  
}

?>

